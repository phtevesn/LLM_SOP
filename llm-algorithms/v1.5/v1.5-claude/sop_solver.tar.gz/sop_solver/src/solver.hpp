// solver.hpp -- top-level orchestration of heuristic and exact phases.
#pragma once
#include <vector>
#include "common.hpp"
#include "model.hpp"

namespace sop {

struct SolverOptions {
  double timeLimit = 0;       // seconds from program start; <= 0 means unlimited
  int threads = 1;
  size_t ttBytes = 0;         // 0 = choose automatically
  u64 seed = 20240607;
  double warmOverride = -1;   // advanced: fixed ILS warm-up seconds (>=0), -1 = automatic
  bool exactEnabled = true;   // advanced: false = heuristic only (never reports optimal)
};

struct SolveResult {
  bool found = false;
  std::vector<int> workPath;  // path in working-model indices (may contain dummies)
  i64 cost = -1;
  bool optimal = false;       // proven optimal before the time limit
  u64 nodes = 0;              // exact-search nodes summed over threads
};

SolveResult solveModel(const Model& m, const SolverOptions& opt);

}  // namespace sop
