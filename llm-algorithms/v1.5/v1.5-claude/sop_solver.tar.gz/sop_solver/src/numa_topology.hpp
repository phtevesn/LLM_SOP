// numa_topology.hpp -- NUMA discovery, thread pinning and NUMA-aware allocation.
#pragma once
#include <cstddef>
#include <vector>
#include "common.hpp"

namespace sop {

struct NumaInfo {
  int nodes = 1;                           // NUMA nodes found (>=1)
  std::vector<int> memNodes;               // node ids that own local memory
  std::vector<int> cpuOrder;               // CPU ids in the order threads are pinned
  bool discovered = false;                 // false if /sys could not be read
};

const NumaInfo& numaInfo();                // lazily discovered, cached
void pinCurrentThread(int threadIndex);    // best effort; silent on failure
// Allocates `bytes` of lazily-zeroed memory, interleaved over the memory nodes
// (when more than one exists) and advised for transparent huge pages.
void* numaAllocInterleaved(size_t bytes);
void numaFree(void* p, size_t bytes);
size_t availableMemoryBytes();             // MemAvailable from /proc/meminfo

}  // namespace sop
