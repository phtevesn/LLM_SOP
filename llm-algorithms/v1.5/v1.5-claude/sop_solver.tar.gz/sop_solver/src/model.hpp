// model.hpp -- preprocessed SOP "working model" shared by all solver modules.
#pragma once
#include <vector>
#include "common.hpp"
#include "instance.hpp"

namespace sop {

// The working model always has ONE start node `s` and ONE end node `e`.
// If the precedence relation has several sources (or sinks) a zero-cost dummy
// start (or end) node is appended, so every algorithm downstream can assume a
// Hamiltonian path from s to e. Real nodes keep their input indices 0..N-1;
// dummies get indices N (start) and N or N+1 (end).
struct Model {
  int N = 0;            // real nodes
  int n = 0;            // working nodes (N + dummies)
  int s = -1, e = -1;   // working start / end
  bool dummyStart = false, dummyEnd = false;
  bool feasible = true; // false if the precedence relation contains a cycle
  int W = 0;            // 64-bit words per bitset row
  std::vector<int> sources, sinks;        // real sources / sinks (before dummies)
  std::vector<i64> cost;                  // n*n; INF_COST marks eliminated arcs
  std::vector<i64> raw;                   // n*n; same costs BEFORE elimination (INF only if T<0 / diagonal)
  std::vector<u64> anc, desc;             // n*W transitive ancestors / descendants
  std::vector<std::vector<int>> preds, succs;  // cover (Hasse) relation = direct constraints
  size_t arcs = 0;                        // number of surviving arcs

  i64 c(int i, int j) const { return cost[static_cast<size_t>(i) * n + j]; }
  i64 rawc(int i, int j) const { return raw[static_cast<size_t>(i) * n + j]; }
  bool isAncestor(int a, int b) const {  // a must precede b
    return (anc[static_cast<size_t>(b) * W + (a >> 6)] >> (a & 63)) & 1ULL;
  }
  // Removes dummy nodes from a working-model path to obtain the real path.
  std::vector<int> toRealPath(const std::vector<int>& workPath) const;
};

// Builds the working model: precedence graph, cycle check, transitive closure,
// start/end derivation (+dummies), cover relation and arc elimination.
Model buildModel(const RawInstance& inst);

}  // namespace sop
