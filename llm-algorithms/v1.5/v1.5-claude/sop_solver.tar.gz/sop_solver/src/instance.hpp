// instance.hpp -- raw SOP instance as read from a TSPLIB-style .sop file.
#pragma once
#include <string>
#include <vector>
#include "common.hpp"

namespace sop {

struct RawInstance {
  std::string name;      // file name (base name) used in the CSV "Instance" column
  int n = 0;             // DIMENSION
  std::vector<i64> t;    // n*n row-major matrix T (T[i][j] < 0 => i depends on j)
  i64 at(int i, int j) const { return t[static_cast<size_t>(i) * n + j]; }
};

// Parses a .sop file. Throws std::runtime_error with a readable message on
// malformed input.
RawInstance parseSopFile(const std::string& path);

}  // namespace sop
