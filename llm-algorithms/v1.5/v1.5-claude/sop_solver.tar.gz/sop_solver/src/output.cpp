// =============================================================================
// output.cpp -- postprocessing: path validity check (permutation, precedence,
// cost recomputation from scratch) and CSV formatting/writing.
// =============================================================================
#include "output.hpp"

#include <cstdio>
#include <fstream>
#include <sys/stat.h>

namespace sop {

Validation validatePath(const RawInstance& inst, const std::vector<int>& path) {
  Validation v;
  const int n = inst.n;
  if (static_cast<int>(path.size()) != n) { v.message = "path length != N"; return v; }
  std::vector<int> pos(n, -1);
  for (int t = 0; t < n; ++t) {  // permutation check
    const int x = path[t];
    if (x < 0 || x >= n) { v.message = "node index out of range"; return v; }
    if (pos[x] != -1) { v.message = "node visited twice"; return v; }
    pos[x] = t;
  }
  for (int i = 0; i < n; ++i)  // precedence check on the raw matrix
    for (int j = 0; j < n; ++j)
      if (i != j && inst.at(i, j) < 0 && pos[j] > pos[i]) {
        v.message = "precedence violated: node " + std::to_string(j) + " must precede " + std::to_string(i);
        return v;
      }
  i64 cost = 0;  // cost recomputed from scratch
  for (int t = 0; t + 1 < n; ++t) {
    const i64 c = inst.at(path[t], path[t + 1]);
    if (c < 0) { v.message = "negative arc on path"; return v; }
    cost += c;
  }
  v.ok = true;
  v.cost = cost;
  return v;
}

std::string csvHeaderLine() {
  return "Instance,Instance Size,Time,Enumerated Nodes,Best Cost,Best Path,Optimal";
}

std::string csvRowLine(const CsvRow& r) {
  std::string name = r.instance;
  if (name.find(',') != std::string::npos || name.find('"') != std::string::npos) {
    std::string q = "\"";
    for (char ch : name) { if (ch == '"') q += '"'; q += ch; }
    name = q + "\"";
  }
  char buf[64];
  std::snprintf(buf, sizeof(buf), "%.6f", r.seconds);
  std::string line = name + "," + std::to_string(r.size) + "," + buf + "," + std::to_string(r.nodes) + "," +
                     std::to_string(static_cast<long long>(r.bestCost)) + ",";
  for (size_t t = 0; t < r.path.size(); ++t) {
    if (t) line += ' ';
    line += std::to_string(r.path[t]);
  }
  line += std::string(",") + (r.optimal ? "yes" : "no");
  return line;
}

bool emitCsv(const CsvRow& r, const std::string& outPath, bool noHeader) {
  const std::string row = csvRowLine(r);
  if (!noHeader) std::printf("%s\n", csvHeaderLine().c_str());
  std::printf("%s\n", row.c_str());
  std::fflush(stdout);
  if (outPath.empty()) return true;
  struct stat st;
  const bool fileHasData = (stat(outPath.c_str(), &st) == 0 && st.st_size > 0);
  std::ofstream f(outPath, std::ios::app);
  if (!f) { logf("error: cannot open output file %s", outPath.c_str()); return false; }
  if (!noHeader && !fileHasData) f << csvHeaderLine() << "\n";
  f << row << "\n";
  return static_cast<bool>(f);
}

}  // namespace sop
