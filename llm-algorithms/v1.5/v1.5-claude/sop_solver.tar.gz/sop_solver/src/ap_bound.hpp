// ap_bound.hpp -- assignment-problem (AP) relaxation used as the root lower bound.
#pragma once
#include <atomic>
#include <vector>
#include "common.hpp"
#include "model.hpp"

namespace sop {

struct ApResult {
  bool valid = false;       // false if aborted (time limit) -> caller uses zero duals
  bool infeasible = false;  // no finite assignment exists => no feasible path
  i64 lb = 0;               // AP optimum = lower bound on any feasible path cost
  std::vector<i64> a;       // row duals, per node (0 for the end node)
  std::vector<i64> b;       // column duals, per node (0 for the start node)
  std::vector<int> rowMate; // optimal matching: successor chosen by each node (-1 for the end node)
  std::vector<int> colMate; // optimal matching: predecessor chosen by each node (-1 for the start)
  // reduced cost r(i,j) = c(i,j) - a[i] - b[j]  (>= 0 for every surviving arc)
  i64 reduced(const Model& m, int i, int j) const { return m.c(i, j) - a[i] - b[j]; }
};

// Solves min-cost assignment of "successor choices": every node except the end
// picks exactly one successor and every node except the start is picked by
// exactly one predecessor. Any Hamiltonian s->e path is such an assignment, so
// the optimum is a valid lower bound, and its dual variables (potentials) give
// non-negative reduced costs that are valid for every sub-problem.
ApResult solveAssignmentBound(const Model& m, const std::atomic<bool>* stop);

}  // namespace sop
