// incumbent.cpp -- thread-safe best-solution store (see incumbent.hpp).
// Purpose: single point where improved upper bounds are recorded and logged.
#include "incumbent.hpp"

namespace sop {

bool Incumbent::offer(i64 cost, const std::vector<int>& workPath, const char* source) {
  if (cost >= best_.load(std::memory_order_relaxed)) return false;  // cheap lock-free reject
  std::lock_guard<std::mutex> lk(mu_);
  if (cost >= best_.load(std::memory_order_relaxed)) return false;
  path_ = workPath;
  best_.store(cost, std::memory_order_relaxed);
  lastImp_.store(globalClock().seconds(), std::memory_order_relaxed);
  logf("new best cost %lld (%s)", static_cast<long long>(cost), source);
  return true;
}

std::vector<int> Incumbent::path() const {
  std::lock_guard<std::mutex> lk(mu_);
  return path_;
}

i64 Incumbent::snapshot(std::vector<int>& out) const {
  std::lock_guard<std::mutex> lk(mu_);
  out = path_;
  return best_.load(std::memory_order_relaxed);
}

}  // namespace sop
