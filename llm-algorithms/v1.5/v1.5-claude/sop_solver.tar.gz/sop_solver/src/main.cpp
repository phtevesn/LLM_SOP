// =============================================================================
// main.cpp -- command-line interface of the SOP exact solver.
//
// Purpose: parse arguments, read the instance, build the working model, run the
// solver, validate the final path against the raw matrix and emit the CSV row.
// All diagnostics go to stderr; stdout carries only the CSV.
// Usage: sop_solver FILE [--time-limit SECONDS] [--threads N] [--output out.csv]
//                        [--no-header] [--tt-mb MB] [--seed S]
// =============================================================================
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <exception>
#include <string>

#include "common.hpp"
#include "instance.hpp"
#include "model.hpp"
#include "output.hpp"
#include "solver.hpp"

using namespace sop;

static void usage() {
  std::fprintf(stderr,
               "usage: sop_solver FILE.sop [--time-limit SECONDS] [--threads N] [--output out.csv]\n"
               "                           [--no-header] [--tt-mb MB] [--seed S]\n");
}

int main(int argc, char** argv) {
  globalClock();  // start the wall clock
  std::string file, outPath;
  SolverOptions opt;
  bool noHeader = false;
  for (int i = 1; i < argc; ++i) {
    const std::string a = argv[i];
    auto need = [&](const char* name) -> const char* {
      if (i + 1 >= argc) { std::fprintf(stderr, "error: %s needs a value\n", name); usage(); std::exit(2); }
      return argv[++i];
    };
    if (a == "--time-limit") opt.timeLimit = std::atof(need("--time-limit"));
    else if (a == "--threads") opt.threads = std::max(1, std::atoi(need("--threads")));
    else if (a == "--output") outPath = need("--output");
    else if (a == "--no-header") noHeader = true;
    else if (a == "--tt-mb") opt.ttBytes = static_cast<size_t>(std::atoll(need("--tt-mb"))) << 20;
    else if (a == "--warmup") opt.warmOverride = std::atof(need("--warmup"));
    else if (a == "--heuristic-only") opt.exactEnabled = false;
    else if (a == "--seed") opt.seed = static_cast<u64>(std::atoll(need("--seed")));
    else if (a == "--help" || a == "-h") { usage(); return 0; }
    else if (!a.empty() && a[0] == '-') { std::fprintf(stderr, "error: unknown option %s\n", a.c_str()); usage(); return 2; }
    else if (file.empty()) file = a;
    else { std::fprintf(stderr, "error: more than one input file given\n"); usage(); return 2; }
  }
  if (file.empty()) { usage(); return 2; }

  RawInstance inst;
  try {
    inst = parseSopFile(file);
  } catch (const std::exception& ex) {
    std::fprintf(stderr, "error: %s\n", ex.what());
    return 1;
  }
  logf("instance %s: N=%d", inst.name.c_str(), inst.n);

  CsvRow row;
  row.instance = inst.name;
  row.size = inst.n;

  std::vector<int> realPath;
  bool found = false, optimal = false;
  u64 nodes = 0;
  if (inst.n == 1) {  // trivial instance
    realPath = {0};
    found = true;
    optimal = true;
  } else if (inst.n >= 2) {
    Model model = buildModel(inst);
    if (!model.feasible) {
      logf("precedence constraints contain a cycle: no feasible path exists");
    } else {
      SolveResult sr = solveModel(model, opt);
      found = sr.found;
      optimal = sr.optimal;
      nodes = sr.nodes;
      if (found) realPath = model.toRealPath(sr.workPath);
    }
  }

  i64 cost = -1;
  if (found) {  // postprocessing: independent validity check on the raw matrix
    Validation v = validatePath(inst, realPath);
    if (!v.ok) {
      logf("INTERNAL ERROR: final path failed validation (%s); reporting no solution", v.message.c_str());
      found = false; optimal = false; realPath.clear();
    } else {
      cost = v.cost;
      logf("validation passed: permutation ok, precedence ok, recomputed cost %lld", static_cast<long long>(cost));
    }
  }
  if (!found) { cost = -1; realPath.clear(); optimal = false; }

  row.seconds = globalClock().seconds();
  row.nodes = nodes;
  row.bestCost = cost;
  row.path = realPath;
  row.optimal = optimal;
  logf("result: cost=%lld optimal=%s time=%.3fs nodes=%llu", static_cast<long long>(cost), optimal ? "yes" : "no",
       row.seconds, static_cast<unsigned long long>(nodes));
  if (!emitCsv(row, outPath, noHeader)) return 1;
  return 0;
}
