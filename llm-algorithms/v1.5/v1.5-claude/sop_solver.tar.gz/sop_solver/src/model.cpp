// =============================================================================
// model.cpp -- preprocessing: precedence graph, closure, start/end derivation,
// dummy nodes, cover relation and static arc elimination.
//
// Techniques implemented here (see ALGORITHMS.md, Table 1):
//   * Kahn topological sort (cycle detection)
//   * bitset transitive closure (ancestor / descendant sets)
//   * start/end derivation from sources/sinks of the closure, with zero-cost
//     dummy start/end when several exist
//   * transitive reduction (cover relation) for O(1)-ish availability checks
//   * static arc elimination: arc (i,j) is dropped when j must precede i, or
//     when some node k must lie strictly between i and j (i < k < j)
// =============================================================================
#include "model.hpp"

#include <algorithm>
#include <queue>

namespace sop {

namespace {
inline void setBit(std::vector<u64>& b, size_t row, int W, int col) {
  b[row * W + (col >> 6)] |= (1ULL << (col & 63));
}
}  // namespace

std::vector<int> Model::toRealPath(const std::vector<int>& workPath) const {
  std::vector<int> out;
  out.reserve(workPath.size());
  for (int v : workPath)
    if (v < N) out.push_back(v);
  return out;
}

Model buildModel(const RawInstance& inst) {
  Model m;
  const int N = inst.n;
  m.N = N;

  // ---- Direct precedence graph from negative entries: T[i][j] < 0 => j before i
  std::vector<std::vector<int>> dpred(N), dsucc(N);
  for (int i = 0; i < N; ++i)
    for (int j = 0; j < N; ++j)
      if (i != j && inst.at(i, j) < 0) {
        dpred[i].push_back(j);
        dsucc[j].push_back(i);
      }

  // ---- Kahn topological sort; a leftover node means a precedence cycle -----
  std::vector<int> indeg(N), topo;
  topo.reserve(N);
  std::queue<int> q;
  for (int i = 0; i < N; ++i) {
    indeg[i] = static_cast<int>(dpred[i].size());
    if (indeg[i] == 0) q.push(i);
  }
  while (!q.empty()) {
    int u = q.front(); q.pop();
    topo.push_back(u);
    for (int x : dsucc[u])
      if (--indeg[x] == 0) q.push(x);
  }
  if (static_cast<int>(topo.size()) != N) {
    m.feasible = false;
    return m;
  }

  // ---- Bitset transitive closure (rows sized for up to two dummy nodes) ----
  const int Wmax = (N + 2 + 63) / 64;
  std::vector<u64> anc(static_cast<size_t>(N + 2) * Wmax, 0), desc(static_cast<size_t>(N + 2) * Wmax, 0);
  for (int u : topo)  // ancestors in topological order
    for (int p : dpred[u]) {
      setBit(anc, u, Wmax, p);
      for (int w = 0; w < Wmax; ++w) anc[static_cast<size_t>(u) * Wmax + w] |= anc[static_cast<size_t>(p) * Wmax + w];
    }
  for (auto it = topo.rbegin(); it != topo.rend(); ++it) {  // descendants in reverse order
    int u = *it;
    for (int x : dsucc[u]) {
      setBit(desc, u, Wmax, x);
      for (int w = 0; w < Wmax; ++w) desc[static_cast<size_t>(u) * Wmax + w] |= desc[static_cast<size_t>(x) * Wmax + w];
    }
  }

  // ---- Derive start / end: sources and sinks of the precedence order -------
  for (int i = 0; i < N; ++i) {
    if (dpred[i].empty()) m.sources.push_back(i);
    if (dsucc[i].empty()) m.sinks.push_back(i);
  }
  m.dummyStart = m.sources.size() > 1;
  m.dummyEnd = m.sinks.size() > 1;
  const int ds = N;
  const int de = N + (m.dummyStart ? 1 : 0);
  m.n = N + (m.dummyStart ? 1 : 0) + (m.dummyEnd ? 1 : 0);
  m.s = m.dummyStart ? ds : m.sources[0];
  m.e = m.dummyEnd ? de : m.sinks[0];
  m.W = Wmax;
  const int n = m.n;
  m.anc.swap(anc);
  m.desc.swap(desc);
  m.anc.resize(static_cast<size_t>(n) * Wmax);
  m.desc.resize(static_cast<size_t>(n) * Wmax);
  if (m.dummyStart) {
    for (int i = 0; i < N; ++i) { setBit(m.anc, i, Wmax, ds); setBit(m.desc, ds, Wmax, i); }
  }
  if (m.dummyEnd) {
    for (int i = 0; i < N; ++i) { setBit(m.desc, i, Wmax, de); setBit(m.anc, de, Wmax, i); }
    if (m.dummyStart) { setBit(m.desc, ds, Wmax, de); setBit(m.anc, de, Wmax, ds); }
  }

  // ---- Cost matrix with dummy arcs (zero cost) and static arc elimination ---
  m.cost.assign(static_cast<size_t>(n) * n, INF_COST);
  for (int i = 0; i < N; ++i)
    for (int j = 0; j < N; ++j)
      if (i != j && inst.at(i, j) >= 0) m.cost[static_cast<size_t>(i) * n + j] = inst.at(i, j);
  if (m.dummyStart)
    for (int j = 0; j < N; ++j) m.cost[static_cast<size_t>(ds) * n + j] = 0;
  if (m.dummyEnd)
    for (int i = 0; i < N; ++i) m.cost[static_cast<size_t>(i) * n + de] = 0;

  m.raw = m.cost;  // keep uneliminated costs (used to cost partial paths in the heuristic)
  m.arcs = 0;
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < n; ++j) {
      i64& c = m.cost[static_cast<size_t>(i) * n + j];
      if (c >= INF_COST) continue;
      bool ok = (i != j) && (i != m.e) && (j != m.s) && !m.isAncestor(j, i);
      if (ok) {  // no node k with i < k < j  (desc[i] & anc[j] must be empty)
        const u64* di = &m.desc[static_cast<size_t>(i) * Wmax];
        const u64* aj = &m.anc[static_cast<size_t>(j) * Wmax];
        for (int w = 0; w < Wmax; ++w)
          if (di[w] & aj[w]) { ok = false; break; }
      }
      if (!ok) c = INF_COST; else ++m.arcs;
    }
  }

  // ---- Cover relation (transitive reduction): p covers x iff p<x and no k in between
  m.preds.assign(n, {});
  m.succs.assign(n, {});
  for (int x = 0; x < n; ++x) {
    const u64* ax = &m.anc[static_cast<size_t>(x) * Wmax];
    for (int p = 0; p < n; ++p) {
      if (!((ax[p >> 6] >> (p & 63)) & 1ULL)) continue;
      const u64* dp = &m.desc[static_cast<size_t>(p) * Wmax];
      bool between = false;
      for (int w = 0; w < Wmax; ++w)
        if (dp[w] & ax[w]) { between = true; break; }
      if (!between) { m.preds[x].push_back(p); m.succs[p].push_back(x); }
    }
  }
  return m;
}

}  // namespace sop
