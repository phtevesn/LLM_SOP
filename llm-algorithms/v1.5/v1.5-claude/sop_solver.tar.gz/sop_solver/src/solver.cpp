// =============================================================================
// solver.cpp -- orchestration of the whole solution pipeline.
//
// Pipeline (see ALGORITHMS.md):
//   1. Heuristic warm-up on all threads (ILS) while the main thread computes the
//      assignment-problem root bound and its dual potentials.
//   2. Exact parallel branch and bound with DP dominance. A few extra ILS
//      threads keep running during this phase so a hopeless proof still
//      improves the incumbent (hybrid heuristic + exact design).
//   3. Optimality is reported only if the exact search exhausted its space
//      before the time limit.
// A watchdog thread raises a global stop flag when the time limit expires.
// =============================================================================
#include "solver.hpp"

#include <algorithm>
#include <chrono>
#include <thread>

#include "ap_bound.hpp"
#include "exact_search.hpp"
#include "heuristic.hpp"
#include "incumbent.hpp"
#include "numa_topology.hpp"

namespace sop {

SolveResult solveModel(const Model& m, const SolverOptions& opt) {
  SolveResult out;
  const double deadline = opt.timeLimit > 0 ? opt.timeLimit : 1e18;
  const int T = std::max(1, opt.threads);
  const int n = m.n;
  Incumbent inc;
  std::atomic<bool> stop{false};        // global stop (time limit / finished)
  std::atomic<bool> watchdogQuit{false};

  // Watchdog: raises `stop` when the wall-clock limit expires.
  std::thread watchdog;
  if (opt.timeLimit > 0)
    watchdog = std::thread([&]() {
      while (!watchdogQuit.load() && globalClock().seconds() < deadline)
        std::this_thread::sleep_for(std::chrono::milliseconds(5));
      if (!watchdogQuit.load()) stop.store(true);
    });

  logf("model: N=%d, working nodes=%d, start=%d%s, end=%d%s, surviving arcs=%zu, threads=%d",
       m.N, n, m.s, m.dummyStart ? " (dummy)" : "", m.e, m.dummyEnd ? " (dummy)" : "", m.arcs, T);

  // ---- Phase 1: heuristic warm-up concurrent with the AP bound --------------
  const int Kcand = std::max(1, std::min(12, n - 1));
  const HeuristicData hdRaw = buildHeuristicData(m, Kcand);
  HeuristicData hdRed;                                   // filled once the AP duals exist
  std::atomic<const HeuristicData*> hdPtr{&hdRaw};
  double warm = n <= 12 ? 0.0 : std::min(8.0, std::max(0.02, 0.003 * n));
  double hardWarm = 30.0;                                 // cap on warm-up extension
  if (opt.warmOverride >= 0) { warm = opt.warmOverride; hardWarm = warm; }
  else if (opt.timeLimit > 0) { warm = std::min(warm, 0.25 * opt.timeLimit); hardWarm = std::min(hardWarm, 0.25 * opt.timeLimit); }
  hardWarm = std::max(hardWarm, warm);
  // warm-up extends while the incumbent keeps improving (stall window), up to hardWarm
  const double stallWin = n <= 12 ? 0.0 : std::min(2.0, std::max(0.01, 0.002 * n));
  const double warmEnd = globalClock().seconds() + warm;
  const double warmHard = globalClock().seconds() + hardWarm;
  {
    std::vector<IlsWorker> workers;
    workers.reserve(T);
    for (int i = 0; i < T; ++i) workers.emplace_back(m, hdPtr, inc, opt.seed + 7919ull * (i + 1));
    std::vector<std::thread> th;
    for (int i = 1; i < T; ++i)
      th.emplace_back([&, i]() {
        if (T > 1) pinCurrentThread(i);
        workers[i].run(stop, warmEnd, warmHard, stallWin);
      });
    if (T > 1) pinCurrentThread(0);
    ApResult ap = solveAssignmentBound(m, &stop);  // main thread: root lower bound
    if (ap.valid && ap.infeasible) {
      logf("assignment relaxation infeasible: no precedence-feasible path exists");
    } else if (ap.valid) {
      logf("assignment lower bound at root: %lld", static_cast<long long>(ap.lb));
    }
    if (ap.valid && !ap.infeasible) {  // publish reduced-cost candidates to the running ILS workers
      hdRed = buildHeuristicData(m, Kcand, &ap);
      hdPtr.store(&hdRed);
    }
    workers[0].run(stop, warmEnd, warmHard, stallWin);  // main thread joins the warm-up
    for (auto& t : th) t.join();

    if (stop.load() || (ap.valid && ap.infeasible)) {
      // time limit hit during warm-up (or infeasible): report what we have
      watchdogQuit.store(true);
      if (watchdog.joinable()) watchdog.join();
      out.found = inc.hasSolution();
      if (out.found) { out.cost = inc.cost(); out.workPath = inc.path(); }
      return out;
    }

    if (inc.hasSolution())
      logf("warm-up done: upper bound %lld, root lower bound %lld, gap %.3f%%",
           static_cast<long long>(inc.cost()), static_cast<long long>(ap.lb),
           inc.cost() > 0 ? 100.0 * (inc.cost() - ap.lb) / inc.cost() : 0.0);

    if (!opt.exactEnabled) {
      watchdogQuit.store(true);
      if (watchdog.joinable()) watchdog.join();
      out.found = inc.hasSolution();
      if (out.found) { out.cost = inc.cost(); out.workPath = inc.path(); }
      return out;
    }
    // ---- Phase 2: exact search + continuing ILS threads ---------------------
    const int H = T >= 4 ? std::max(1, T / 8) : 0;  // heuristic threads kept alive
    const int E = T - H;
    ExactOptions eo;
    eo.threads = E;
    eo.cpuOffset = H;
    eo.deadline = deadline;
    eo.seed = opt.seed ^ 0xABCDEF1234567ULL;
    size_t tt = opt.ttBytes;
    if (tt == 0) {  // default: a quarter of the available memory, at most 16 GiB
      tt = availableMemoryBytes() / 4;
      tt = std::min<size_t>(tt, 16ull << 30);
      tt = std::max<size_t>(tt, 64ull << 20);
    }
    eo.ttBytes = tt;
    std::vector<IlsWorker> keep;
    keep.reserve(H);
    for (int i = 0; i < H; ++i) keep.emplace_back(m, hdPtr, inc, opt.seed + 104729ull * (i + 11));
    std::vector<std::thread> kth;
    for (int i = 0; i < H; ++i)
      kth.emplace_back([&, i]() {
        pinCurrentThread(i);
        keep[i].run(stop, 1e18, 1e18, 0.0);
      });
    ExactResult er = runExactSearch(m, ap, inc, eo, stop);
    stop.store(true);  // ends the continuing ILS threads
    for (auto& t : kth) t.join();
    out.nodes = er.nodes;
    out.optimal = er.completed && inc.hasSolution();
    out.found = inc.hasSolution();
    if (out.found) { out.cost = inc.cost(); out.workPath = inc.path(); }
    logf("exact search %s after %llu nodes", er.completed ? "completed" : "stopped (not proven)",
         static_cast<unsigned long long>(er.nodes));
  }
  watchdogQuit.store(true);
  if (watchdog.joinable()) watchdog.join();
  return out;
}

}  // namespace sop
