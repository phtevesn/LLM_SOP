// =============================================================================
// heuristic.cpp -- upper bounding: randomized greedy construction followed by
// Iterated Local Search (ILS) over precedence-feasible segment relocations.
//
// Techniques implemented here (see ALGORITHMS.md, Table 2b):
//   * Randomized nearest-neighbour construction respecting precedence
//   * Segment-insertion (Or-opt / "3-exchange without reversal") local search
//     with K-nearest candidate lists and O(segment) precedence feasibility
//     test, in the spirit of SOP-3-exchange (Gambardella & Dorigo 2000)
//   * Don't-look-bit style work stack: only touched nodes are re-examined
//   * ILS: random feasible segment-relocation kicks, accept-if-not-worse,
//     restarts from the shared best or from a fresh randomized construction
// Feasibility argument: moving segment [i..j] past a block of nodes is legal
// iff no cover-edge links the segment to that block in the wrong direction.
// =============================================================================
#include "heuristic.hpp"

#include <algorithm>
#include <functional>
#include <queue>

namespace sop {

HeuristicData buildHeuristicData(const Model& m, int K, const ApResult* ap) {
  HeuristicData hd;
  const int n = m.n;
  hd.K = K;
  if (ap && ap->valid && !ap->infeasible) { hd.reduced = true; hd.redA = ap->a; hd.redB = ap->b; hd.apSucc = ap->rowMate; }
  auto key = [&](int u, int v) { return hd.reduced ? m.c(u, v) - hd.redA[u] - hd.redB[v] : m.c(u, v); };
  hd.candIn.assign(n, {});
  hd.candOut.assign(n, {});
  std::vector<std::pair<i64, int>> tmp;
  for (int v = 0; v < n; ++v) {
    tmp.clear();  // K cheapest predecessors u of v
    for (int u = 0; u < n; ++u)
      if (m.c(u, v) < INF_COST) tmp.emplace_back(key(u, v), u);
    size_t k = std::min<size_t>(K, tmp.size());
    std::partial_sort(tmp.begin(), tmp.begin() + k, tmp.end());
    for (size_t t = 0; t < k; ++t) hd.candIn[v].push_back(tmp[t].second);
    tmp.clear();  // K cheapest successors w of v
    for (int w = 0; w < n; ++w)
      if (m.c(v, w) < INF_COST) tmp.emplace_back(key(v, w), w);
    k = std::min<size_t>(K, tmp.size());
    std::partial_sort(tmp.begin(), tmp.begin() + k, tmp.end());
    for (size_t t = 0; t < k; ++t) hd.candOut[v].push_back(tmp[t].second);
  }
  return hd;
}

IlsWorker::IlsWorker(const Model& m, const std::atomic<const HeuristicData*>& src, Incumbent& inc, u64 seed)
    : m_(m), src_(src), hd_(src.load()), inc_(inc), rng_(seed), n_(m.n) {
  maxSeg_ = std::max(1, std::min(n_ - 2, 30));
  p_.assign(n_, 0);
  pos_.assign(n_, 0);
  inStack_.assign(n_, 0);
}

i64 IlsWorker::arcKey(int i, int j) const {
  const i64 c = m_.c(i, j);
  return hd_->reduced && c < INF_COST ? c - hd_->redA[i] - hd_->redB[j] : c;
}

void IlsWorker::rebuildPos() {
  for (int t = 0; t < n_; ++t) pos_[p_[t]] = t;
}

i64 IlsWorker::pathCost() const {
  i64 c = 0;
  for (int t = 0; t + 1 < n_; ++t) c += m_.c(p_[t], p_[t + 1]);
  return c;
}

// ---- Randomized nearest-neighbour construction (precedence aware) ----------
bool IlsWorker::construct() {
  std::vector<int> cnt(n_);
  std::vector<int> avail;
  for (int v = 0; v < n_; ++v) cnt[v] = static_cast<int>(m_.preds[v].size());
  p_.clear();
  p_.push_back(m_.s);
  for (int x : m_.succs[m_.s])
    if (--cnt[x] == 0) avail.push_back(x);
  while (static_cast<int>(p_.size()) < n_) {
    if (avail.empty()) return false;
    const int cur = p_.back();
    // pick among the 3 cheapest available nodes with probabilities .70/.20/.10
    int bestIdx[3] = {-1, -1, -1};
    i64 bestC[3] = {INF_COST * 4, INF_COST * 4, INF_COST * 4};
    for (int t = 0; t < static_cast<int>(avail.size()); ++t) {
      i64 c = arcKey(cur, avail[t]);
      for (int r = 0; r < 3; ++r) {
        if (c < bestC[r]) {
          for (int q = 2; q > r; --q) { bestC[q] = bestC[q - 1]; bestIdx[q] = bestIdx[q - 1]; }
          bestC[r] = c; bestIdx[r] = t;
          break;
        }
      }
    }
    double u = rng_.uniform();
    int r = (u < 0.70 || bestIdx[1] < 0) ? 0 : (u < 0.90 || bestIdx[2] < 0 ? 1 : 2);
    int t = bestIdx[r];
    int v = avail[t];
    avail[t] = avail.back();
    avail.pop_back();
    p_.push_back(v);
    for (int x : m_.succs[v])
      if (--cnt[x] == 0) avail.push_back(x);
  }
  rebuildPos();
  cost_ = pathCost();
  return cost_ < INF_COST;
}

// ---- AP cycle patching + cheapest feasible reinsertion ----------------------
// Karp-style patching (Karp 1979): the assignment optimum is one s..e path plus
// disjoint cycles; each cycle is spliced into the growing path at the cheapest
// (path arc, cycle arc) pair, ignoring precedence. The resulting sequence is
// scanned left to right keeping every node that does not conflict with already
// kept nodes (a node conflicts if one of its descendants was kept earlier); the
// conflicting nodes are then reinserted one by one at their cheapest position
// inside the interval allowed by their kept ancestors/descendants (closure).
bool IlsWorker::constructAp(bool randomized) {
  if (!hd_->reduced || static_cast<int>(hd_->apSucc.size()) != n_) return false;
  const std::vector<int>& succ = hd_->apSucc;
  std::vector<int> next(n_, -1);
  std::vector<char> seen(n_, 0);
  for (int cur = m_.s;;) {
    seen[cur] = 1;
    if (cur == m_.e) break;
    const int nx = succ[cur];
    if (nx < 0 || seen[nx]) return false;
    next[cur] = nx;
    cur = nx;
  }
  std::vector<std::vector<int>> cycles;
  for (int v = 0; v < n_; ++v) {
    if (seen[v]) continue;
    std::vector<int> cyc;
    int u = v;
    do { cyc.push_back(u); seen[u] = 1; u = succ[u]; } while (u >= 0 && u != v && !seen[u]);
    if (u != v) return false;
    cycles.push_back(std::move(cyc));
  }
  if (randomized) for (size_t t = cycles.size(); t > 1; --t) std::swap(cycles[t - 1], cycles[rng_.below(t)]);
  else std::sort(cycles.begin(), cycles.end(), [](const auto& a, const auto& b) { return a.size() < b.size(); });
  // 1. patch cycles into the main path (precedence ignored)
  for (auto& cyc : cycles) {
    struct Opt { i64 delta; int a; int i; };
    Opt top[3] = {{INF_COST * 4, -1, -1}, {INF_COST * 4, -1, -1}, {INF_COST * 4, -1, -1}};
    const int k = static_cast<int>(cyc.size());
    for (int a = m_.s; a != m_.e; a = next[a]) {
      const int b = next[a];
      const i64 cab = m_.rawc(a, b);
      if (cab >= INF_COST) continue;
      for (int i = 0; i < k; ++i) {
        const int ci = cyc[i], cj = cyc[(i + 1) % k];
        const i64 c1 = m_.rawc(a, cj), c2 = m_.rawc(ci, b), c3 = (k == 1 ? 0 : m_.rawc(ci, cj));
        if (c1 >= INF_COST || c2 >= INF_COST || c3 >= INF_COST) continue;
        const i64 delta = c1 + c2 - c3 - cab;
        for (int q = 0; q < 3; ++q)
          if (delta < top[q].delta) {
            for (int w = 2; w > q; --w) top[w] = top[w - 1];
            top[q] = {delta, a, i};
            break;
          }
      }
    }
    int q = 0;
    if (randomized) { const double u = rng_.uniform(); q = u < 0.6 ? 0 : (u < 0.85 ? 1 : 2); }
    while (q > 0 && top[q].a < 0) --q;
    if (top[q].a < 0) return false;
    const int a = top[q].a, i = top[q].i, b = next[a];
    const int ci = cyc[i], cj = cyc[(i + 1) % k];
    for (int t = 0; t < k; ++t) next[cyc[t]] = cyc[(t + 1) % k];
    next[a] = cj;
    next[ci] = b;
  }
  // 2. scan: keep non-conflicting nodes, defer the rest
  std::vector<u64> kept(m_.W, 0);
  std::vector<int> path, deferred;
  for (int v = m_.s;; v = next[v]) {
    const u64* d = &m_.desc[static_cast<size_t>(v) * m_.W];
    bool conflict = false;
    for (int w = 0; w < m_.W; ++w) if (d[w] & kept[w]) { conflict = true; break; }
    if (conflict && v != m_.e) deferred.push_back(v);
    else { path.push_back(v); kept[v >> 6] |= 1ULL << (v & 63); }
    if (v == m_.e) break;
  }
  if (path.empty() || path.back() != m_.e) return false;
  // 3. reinsert deferred nodes at their cheapest feasible position
  for (int x : deferred) {
    const int len = static_cast<int>(path.size());
    int lo = -1, hi = len;
    for (int t = 0; t < len; ++t) {
      const int y = path[t];
      if (m_.isAncestor(y, x)) lo = std::max(lo, t);
      else if (m_.isAncestor(x, y)) hi = std::min(hi, t);
    }
    const int paMax = std::min(hi - 1, len - 2), paMin = std::max(lo, 0);
    if (paMin > paMax) return false;
    struct Opt { i64 delta; int pa; };
    Opt top[3] = {{INF_COST * 4, -1}, {INF_COST * 4, -1}, {INF_COST * 4, -1}};
    for (int pa = paMin; pa <= paMax; ++pa) {
      const int a = path[pa], b = path[pa + 1];
      const i64 cab = m_.rawc(a, b), c1 = m_.rawc(a, x), c2 = m_.rawc(x, b);
      if (cab >= INF_COST || c1 >= INF_COST || c2 >= INF_COST) continue;
      const i64 delta = c1 + c2 - cab;
      for (int q = 0; q < 3; ++q)
        if (delta < top[q].delta) {
          for (int w = 2; w > q; --w) top[w] = top[w - 1];
          top[q] = {delta, pa};
          break;
        }
    }
    int q = 0;
    if (randomized) { const double u = rng_.uniform(); q = u < 0.7 ? 0 : (u < 0.9 ? 1 : 2); }
    while (q > 0 && top[q].pa < 0) --q;
    if (top[q].pa < 0) return false;
    path.insert(path.begin() + top[q].pa + 1, x);
  }
  if (static_cast<int>(path.size()) != n_) return false;
  p_ = path;
  rebuildPos();
  cost_ = pathCost();
  return cost_ < INF_COST;
}

bool IlsWorker::freshStart() {
  if (hd_->reduced && rng_.uniform() < 0.7 && constructAp(true)) return true;
  return construct();
}

void IlsWorker::pushNode(int v) {
  if (v == m_.s || v == m_.e || inStack_[v]) return;
  inStack_[v] = 1;
  stack_.push_back(v);
}

// ---- Precedence feasibility of moving segment p[i..j] to just after p[k] ----
bool IlsWorker::feasibleMove(int i, int j, int k) const {
  if (k > j) {  // forward: segment jumps over positions j+1..k
    int limit = n_;
    for (int t = i; t <= j; ++t)
      for (int d : m_.succs[p_[t]])
        if (pos_[d] > j && pos_[d] < limit) limit = pos_[d];
    return k < limit;
  }
  // backward: segment jumps in front of positions k+1..i-1
  int limit = -1;
  for (int t = i; t <= j; ++t)
    for (int q : m_.preds[p_[t]])
      if (pos_[q] < i && pos_[q] > limit) limit = pos_[q];
  return k >= limit;
}

void IlsWorker::applyMove(int i, int j, int k, i64 delta) {
  const int prev = p_[i - 1], next = p_[j + 1], A = p_[i], B = p_[j];
  const int x = p_[k], y = p_[k + 1];
  if (k > j) {
    std::rotate(p_.begin() + i, p_.begin() + j + 1, p_.begin() + k + 1);
    for (int t = i; t <= k; ++t) pos_[p_[t]] = t;
  } else {
    std::rotate(p_.begin() + k + 1, p_.begin() + i, p_.begin() + j + 1);
    for (int t = k + 1; t <= j; ++t) pos_[p_[t]] = t;
  }
  cost_ += delta;
  pushNode(prev); pushNode(next); pushNode(A); pushNode(B); pushNode(x); pushNode(y);
}

// ---- Segment-insertion local search step: best improving relocation --------
bool IlsWorker::tryMove(int i, int j) {
  const int prev = p_[i - 1], next = p_[j + 1], A = p_[i], B = p_[j];
  const i64 cpn = m_.c(prev, next);
  if (cpn >= INF_COST) return false;
  const i64 rem = m_.c(prev, A) + m_.c(B, next) - cpn;  // saving from cutting the segment out
  struct Cand { i64 delta; int k; };
  Cand cands[64];
  int nc = 0;
  auto consider = [&](int k) {
    if (k < 0 || k > n_ - 2 || (k >= i - 1 && k <= j)) return;
    const int x = p_[k], y = p_[k + 1];
    const i64 cxA = m_.c(x, A), cBy = m_.c(B, y), cxy = m_.c(x, y);
    if (cxA >= INF_COST || cBy >= INF_COST || cxy >= INF_COST) return;
    const i64 delta = cxA + cBy - cxy - rem;
    if (delta < 0 && nc < 64) cands[nc++] = {delta, k};
  };
  for (int x : hd_->candIn[A]) consider(pos_[x]);        // new arc (x, A) is cheap
  for (int y : hd_->candOut[B]) consider(pos_[y] - 1);   // new arc (B, y) is cheap
  if (nc == 0) return false;
  std::sort(cands, cands + nc, [](const Cand& a, const Cand& b) { return a.delta < b.delta; });
  for (int t = 0; t < nc; ++t) {
    if (t > 0 && cands[t].k == cands[t - 1].k) continue;
    if (feasibleMove(i, j, cands[t].k)) {
      applyMove(i, j, cands[t].k, cands[t].delta);
      return true;
    }
  }
  return false;
}

void IlsWorker::localSearch() {
  while (!stack_.empty()) {
    const int a = stack_.back();
    stack_.pop_back();
    inStack_[a] = 0;
    bool improved = true;
    while (improved) {
      improved = false;
      int i = pos_[a];
      for (int L = 1; L <= maxSeg_ && !improved; ++L) {  // segments starting at a
        const int j = i + L - 1;
        if (j > n_ - 2) break;
        improved = tryMove(i, j);
      }
      if (improved) continue;
      const int j = pos_[a];
      for (int L = 2; L <= maxSeg_ && !improved; ++L) {  // segments ending at a
        const int ii = j - L + 1;
        if (ii < 1) break;
        improved = tryMove(ii, j);
      }
    }
  }
}

// ---- ILS perturbation: random feasible segment relocations ------------------
void IlsWorker::kick(int strength) {
  for (int s = 0; s < strength; ++s) {
    for (int attempt = 0; attempt < 30; ++attempt) {
      const int L = 1 + static_cast<int>(rng_.below(std::min(n_ - 2, 3 * maxSeg_ / 2)));
      const int i = 1 + static_cast<int>(rng_.below(n_ - 2));
      const int j = i + L - 1;
      if (j > n_ - 2) continue;
      // local kick: the insertion point lies within a window of +-W positions
      // (a "local double bridge"), so the perturbation damages few arcs
      const int W = 20 + static_cast<int>(rng_.below(60));
      int k = j + static_cast<int>(rng_.below(2 * W + 1)) - W;
      if (k < 0 || k > n_ - 2) continue;
      if (k >= i - 1 && k <= j) continue;
      const int prev = p_[i - 1], next = p_[j + 1], A = p_[i], B = p_[j], x = p_[k], y = p_[k + 1];
      const i64 cpn = m_.c(prev, next);
      if (cpn >= INF_COST) continue;
      if (m_.c(x, A) >= INF_COST || m_.c(B, y) >= INF_COST) continue;
      if (!feasibleMove(i, j, k)) continue;
      const i64 delta = m_.c(x, A) + m_.c(B, y) - m_.c(x, y) - (m_.c(prev, A) + m_.c(B, next) - cpn);
      applyMove(i, j, k, delta);
      break;
    }
  }
}

void IlsWorker::run(const std::atomic<bool>& stop, double deadline, double hardDeadline, double stallWindow) {
  if (n_ < 4) {  // 0..2 free nodes: trivial, handled by exact search
    if (construct()) inc_.offer(cost_, p_, "greedy");
    return;
  }
  auto timeUp = [&]() {
    if (stop.load(std::memory_order_relaxed)) return true;
    const double now = globalClock().seconds();
    if (now >= hardDeadline) return true;
    return now >= deadline && now - inc_.lastImprovement() >= stallWindow;  // warm-up extends while improving
  };
  std::vector<int> savedP, bestP;
  i64 bestCost = NO_SOLUTION;
  auto fullDescent = [&]() {
    for (int v = 0; v < n_; ++v) pushNode(v);
    std::vector<int> order = stack_;
    for (size_t t = order.size(); t > 1; --t) std::swap(order[t - 1], order[rng_.below(t)]);
    stack_ = order;
    localSearch();
  };
  hd_ = src_.load();
  int tries = 0;
  while (!((hd_->reduced && constructAp(false)) || construct())) { if (++tries > 20 || timeUp()) return; }
  fullDescent();
  bestCost = cost_; bestP = p_;
  inc_.offer(bestCost, bestP, "ILS init");
  u64 stall = 0;
  const u64 stallLimit = std::max<u64>(3000, 40ull * n_);
  while (!timeUp()) {
    if (src_.load() != hd_) {  // better candidate data published (AP finished): restart with it
      hd_ = src_.load();
      if (constructAp(false) || construct()) { fullDescent(); if (cost_ < bestCost) { bestCost = cost_; bestP = p_; inc_.offer(bestCost, bestP, "ILS AP-patch start"); } }
      stall = 0;
    }
    for (int rep = 0; rep < 32; ++rep) {
      ++iters_;
      savedP = p_;
      const i64 savedCost = cost_;
      kick(2 + static_cast<int>(rng_.below(3)));
      localSearch();
      if (cost_ < bestCost) {
        bestCost = cost_; bestP = p_; stall = 0;
        inc_.offer(bestCost, bestP, "ILS");
      }
      if (cost_ > savedCost) {  // reject: restore previous solution
        p_ = savedP; cost_ = savedCost; rebuildPos();
      } else if (cost_ == savedCost) {
        ++stall;
      } else {
        stall = 0;
      }
      ++stall;
    }
    if (stall > stallLimit) {  // restart: shared best + strong kick, or fresh construction
      stall = 0;
      if (rng_.uniform() < 0.5 && inc_.hasSolution()) {
        std::vector<int> g;
        inc_.snapshot(g);
        if (static_cast<int>(g.size()) == n_) {
          p_ = g; rebuildPos(); cost_ = pathCost();
          kick(6 + static_cast<int>(rng_.below(10)));
          localSearch();
        }
      } else if (freshStart()) {
        fullDescent();
      }
      if (cost_ < bestCost) { bestCost = cost_; bestP = p_; inc_.offer(bestCost, bestP, "ILS restart"); }
    }
  }
}

}  // namespace sop
