// transposition_table.hpp -- shared lock-free dominance table for the exact search.
#pragma once
#include <atomic>
#include "common.hpp"

namespace sop {

// Stores, for visited state (S = set of visited nodes, v = last node), the best
// (smallest) reduced path cost g with which the state has been reached.
// A later arrival with g' >= g is dominated: both continue with the identical
// set of remaining nodes from the identical last node, so the cheaper prefix
// always wins (Held-Karp dynamic-programming dominance).
//
// Slots are 32 bytes {key1, key2, data, check}; key1/key2 are two independent
// 64-bit Zobrist hashes (128-bit identity), `check` = key1^key2^data detects
// torn concurrent writes. Two slots form one cache-line bucket: slot 0 is
// depth-preferred (shallow states have larger subtrees), slot 1 always-replace.
// The table is lossy (entries can be overwritten) which only costs speed,
// never correctness.
class TranspositionTable {
 public:
  explicit TranspositionTable(size_t bytes);
  ~TranspositionTable();
  TranspositionTable(const TranspositionTable&) = delete;
  TranspositionTable& operator=(const TranspositionTable&) = delete;
  bool ok() const { return slots_ != nullptr; }
  size_t bytes() const { return bytes_; }
  // true  -> state is dominated (already reached with cost <= g): prune it
  // false -> state is new or improved: it has been recorded, explore it
  bool probeAndStore(u64 k1, u64 k2, i64 g, int depth);

 private:
  struct Slot { std::atomic<u64> w[4]; };
  Slot* slots_ = nullptr;
  size_t bytes_ = 0;
  u64 bucketMask_ = 0;
};

}  // namespace sop
