// incumbent.hpp -- thread-safe store of the best solution found so far.
#pragma once
#include <atomic>
#include <mutex>
#include <vector>
#include "common.hpp"

namespace sop {

// Shared incumbent: every heuristic or exact thread calls offer(); the best
// (lowest) cost is readable lock-free so branch and bound can prune with it.
class Incumbent {
 public:
  Incumbent() : best_(NO_SOLUTION), lastImp_(0.0) {}
  double lastImprovement() const { return lastImp_.load(std::memory_order_relaxed); }  // clock seconds
  i64 cost() const { return best_.load(std::memory_order_relaxed); }
  bool hasSolution() const { return cost() < NO_SOLUTION; }
  // Returns true if the offered solution improved the incumbent. Logs every
  // improvement of the global best (as required) to stderr.
  bool offer(i64 cost, const std::vector<int>& workPath, const char* source);
  std::vector<int> path() const;
  // Copies path and returns its cost atomically (for heuristic restarts).
  i64 snapshot(std::vector<int>& out) const;
 private:
  std::atomic<i64> best_;
  std::atomic<double> lastImp_;
  mutable std::mutex mu_;
  std::vector<int> path_;
};

}  // namespace sop
