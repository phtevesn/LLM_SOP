// =============================================================================
// instance.cpp -- TSPLIB-style .sop file parser.
//
// Purpose: turn the text file into a RawInstance (dimension + full matrix).
// Algorithm: single-pass tokenizer. Header lines are parsed by keyword
// (KEY : value); the first line whose keyword is EDGE_WEIGHT_SECTION switches
// to numeric mode, where all following whitespace-separated integers are read
// regardless of line wrapping. The repeated dimension N that follows the
// keyword is detected and skipped; a trailing EOF line (or its absence) is
// tolerated because numeric reading simply stops at the first non-integer.
// =============================================================================
#include "instance.hpp"

#include <cctype>
#include <cerrno>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <stdexcept>

namespace sop {

namespace {

std::string trim(const std::string& s) {
  size_t a = 0, b = s.size();
  while (a < b && std::isspace(static_cast<unsigned char>(s[a]))) ++a;
  while (b > a && std::isspace(static_cast<unsigned char>(s[b - 1]))) --b;
  return s.substr(a, b - a);
}
std::string upper(std::string s) {
  for (auto& c : s) c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
  return s;
}
std::string baseName(const std::string& path) {
  size_t p = path.find_last_of("/\\");
  return p == std::string::npos ? path : path.substr(p + 1);
}

}  // namespace

RawInstance parseSopFile(const std::string& path) {
  std::ifstream in(path, std::ios::binary);
  if (!in) throw std::runtime_error("cannot open file: " + path);
  std::stringstream ss;
  ss << in.rdbuf();
  const std::string text = ss.str();

  RawInstance inst;
  inst.name = baseName(path);
  int dimension = -1;
  std::string weightFormat = "FULL_MATRIX";

  // ---- Header section: parse "KEY : value" lines by keyword ----------------
  size_t pos = 0;
  bool sawSection = false;
  while (pos < text.size()) {
    size_t eol = text.find('\n', pos);
    if (eol == std::string::npos) eol = text.size();
    std::string line = trim(text.substr(pos, eol - pos));
    const size_t lineEnd = eol;
    pos = eol + 1;
    if (line.empty()) continue;
    std::string key, value;
    size_t colon = line.find(':');
    if (colon != std::string::npos) {
      key = upper(trim(line.substr(0, colon)));
      value = trim(line.substr(colon + 1));
    } else {
      key = upper(line);
    }
    if (key == "EDGE_WEIGHT_SECTION") {
      sawSection = true;
      pos = std::min(lineEnd + 1, text.size());  // numeric data starts on the next line
      break;
    }
    if (key == "DIMENSION") {
      dimension = static_cast<int>(std::strtol(value.c_str(), nullptr, 10));
    } else if (key == "EDGE_WEIGHT_FORMAT") {
      weightFormat = upper(value);
    } else if (key == "EOF") {
      break;
    }
    // NAME, TYPE, COMMENT, EDGE_WEIGHT_TYPE and unknown keys are metadata only.
  }
  if (!sawSection) throw std::runtime_error("EDGE_WEIGHT_SECTION not found in " + path);
  if (weightFormat != "FULL_MATRIX")
    logf("warning: EDGE_WEIGHT_FORMAT is '%s', expected FULL_MATRIX; reading as full matrix",
         weightFormat.c_str());

  // ---- Numeric section: read every integer until a non-integer token -------
  std::vector<i64> vals;
  const char* p = text.c_str() + pos;
  const char* end = text.c_str() + text.size();
  while (p < end) {
    while (p < end && std::isspace(static_cast<unsigned char>(*p))) ++p;
    if (p >= end) break;
    char* q = nullptr;
    errno = 0;
    long long v = std::strtoll(p, &q, 10);
    if (q == p) break;  // "EOF" or other terminator
    vals.push_back(static_cast<i64>(v));
    p = q;
  }

  if (dimension <= 0) {  // DIMENSION missing: the repeated N is the first token
    if (vals.empty()) throw std::runtime_error("no DIMENSION and no matrix data");
    dimension = static_cast<int>(vals[0]);
  }
  const size_t N = static_cast<size_t>(dimension);
  size_t offset = 0;
  if (vals.size() >= N * N + 1 && vals[0] == static_cast<i64>(N)) offset = 1;  // repeated N
  else if (vals.size() < N * N)
    throw std::runtime_error("matrix has " + std::to_string(vals.size()) + " values, expected " +
                             std::to_string(N * N));
  inst.n = dimension;
  inst.t.assign(vals.begin() + offset, vals.begin() + offset + N * N);
  return inst;
}

}  // namespace sop
