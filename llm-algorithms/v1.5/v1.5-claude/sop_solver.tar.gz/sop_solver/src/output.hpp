// output.hpp -- solution validation and CSV writing.
#pragma once
#include <string>
#include <vector>
#include "common.hpp"
#include "instance.hpp"

namespace sop {

struct Validation {
  bool ok = false;
  i64 cost = -1;          // cost recomputed from the raw matrix
  std::string message;    // reason when !ok
};

// Checks permutation property, every precedence constraint of the RAW matrix
// (T[i][j] < 0 => j before i) and recomputes the cost from scratch.
Validation validatePath(const RawInstance& inst, const std::vector<int>& path);

struct CsvRow {
  std::string instance;
  int size = 0;
  double seconds = 0;
  unsigned long long nodes = 0;
  i64 bestCost = -1;
  std::vector<int> path;
  bool optimal = false;
};

std::string csvHeaderLine();
std::string csvRowLine(const CsvRow& r);
// Prints to stdout (header unless noHeader) and, if outPath is non-empty,
// appends to that file (header only if the file is new/empty and !noHeader).
bool emitCsv(const CsvRow& r, const std::string& outPath, bool noHeader);

}  // namespace sop
