// =============================================================================
// common.hpp -- shared types, timing, logging and random-number utilities.
//
// Purpose: small header-only helpers used by every other module. Nothing in
// here is algorithmic; it only provides (a) fixed-width integer aliases,
// (b) the global wall-clock timer that defines the "Time" CSV column and the
// time limit, (c) thread-safe stderr logging, and (d) a fast PRNG
// (xoshiro256**) used by the heuristic and by the Zobrist hashing.
// =============================================================================
#pragma once
#include <atomic>
#include <chrono>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <mutex>
#include <string>
#include <vector>

namespace sop {

using i64 = std::int64_t;
using u64 = std::uint64_t;
using u32 = std::uint32_t;
using u16 = std::uint16_t;

// Cost value that marks an arc which can never appear in a feasible path.
// Chosen so that sums of ~1000 of them still fit in an i64.
constexpr i64 INF_COST = static_cast<i64>(1) << 50;
// "No incumbent yet" sentinel for the best known cost.
constexpr i64 NO_SOLUTION = INT64_MAX / 4;

// ---- Global wall-clock timer (starts when the program starts) ---------------
class WallClock {
 public:
  WallClock() : t0_(std::chrono::steady_clock::now()) {}
  double seconds() const {
    return std::chrono::duration<double>(std::chrono::steady_clock::now() - t0_).count();
  }
 private:
  std::chrono::steady_clock::time_point t0_;
};
inline WallClock& globalClock() {
  static WallClock c;
  return c;
}

// ---- Thread-safe logging to stderr (stdout is reserved for the CSV) ---------
inline std::mutex& logMutex() {
  static std::mutex m;
  return m;
}
inline void logf(const char* fmt, ...) {
  char buf[1024];
  va_list ap;
  va_start(ap, fmt);
  std::vsnprintf(buf, sizeof(buf), fmt, ap);
  va_end(ap);
  std::lock_guard<std::mutex> lk(logMutex());
  std::fprintf(stderr, "[%9.3fs] %s\n", globalClock().seconds(), buf);
  std::fflush(stderr);
}

// ---- xoshiro256** pseudo random generator (seeded through splitmix64) -------
inline u64 splitmix64(u64& x) {
  u64 z = (x += 0x9E3779B97F4A7C15ULL);
  z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
  z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
  return z ^ (z >> 31);
}
class Rng {
 public:
  explicit Rng(u64 seed = 1) { reseed(seed); }
  void reseed(u64 seed) {
    u64 x = seed;
    for (auto& v : s_) v = splitmix64(x);
  }
  u64 next() {
    const u64 result = rotl(s_[1] * 5, 7) * 9;
    const u64 t = s_[1] << 17;
    s_[2] ^= s_[0]; s_[3] ^= s_[1]; s_[1] ^= s_[2]; s_[0] ^= s_[3];
    s_[2] ^= t; s_[3] = rotl(s_[3], 45);
    return result;
  }
  // uniform integer in [0, n)
  u64 below(u64 n) { return n ? next() % n : 0; }
  // uniform double in [0,1)
  double uniform() { return (next() >> 11) * (1.0 / 9007199254740992.0); }
 private:
  static u64 rotl(u64 x, int k) { return (x << k) | (x >> (64 - k)); }
  u64 s_[4];
};

}  // namespace sop
