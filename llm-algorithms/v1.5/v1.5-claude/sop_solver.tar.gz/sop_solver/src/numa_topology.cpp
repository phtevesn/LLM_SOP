// =============================================================================
// numa_topology.cpp -- NUMA handling for the AMD Threadripper 2990WX.
//
// The 2990WX exposes 4 NUMA nodes (one per die) but only 2 of them have memory
// controllers attached; dies without local memory pay extra latency on every
// access. This file therefore:
//   * discovers nodes, their CPUs and their memory from /sys (no libnuma needed)
//   * orders CPUs so that threads are spread round-robin over the nodes that own
//     memory first, then the memory-less dies, using one hardware thread per
//     physical core before any SMT sibling
//   * pins worker threads with pthread_setaffinity_np so first-touch allocation
//     of per-thread data lands on the thread's own node
//   * places the large shared transposition table with an interleave policy
//     (mbind MPOL_INTERLEAVE over memory nodes) so bandwidth is spread evenly
// Every call is best effort: failures (containers, non-NUMA machines) are ignored.
// =============================================================================
#include "numa_topology.hpp"

#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <set>
#include <sstream>

#include <pthread.h>
#include <sched.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <unistd.h>

namespace sop {

namespace {

std::vector<int> parseCpuList(const std::string& s) {  // "0-7,32-39"
  std::vector<int> out;
  std::stringstream ss(s);
  std::string tok;
  while (std::getline(ss, tok, ',')) {
    if (tok.empty() || !std::isdigit(static_cast<unsigned char>(tok[0]))) continue;
    size_t dash = tok.find('-');
    int a = std::atoi(tok.c_str());
    int b = dash == std::string::npos ? a : std::atoi(tok.c_str() + dash + 1);
    for (int c = a; c <= b; ++c) out.push_back(c);
  }
  return out;
}

bool readFile(const std::string& path, std::string& out) {
  std::ifstream f(path);
  if (!f) return false;
  std::stringstream ss;
  ss << f.rdbuf();
  out = ss.str();
  return true;
}

NumaInfo discover() {
  NumaInfo info;
  // CPUs this process may run on.
  std::set<int> allowed;
  cpu_set_t set;
  CPU_ZERO(&set);
  if (sched_getaffinity(0, sizeof(set), &set) == 0)
    for (int c = 0; c < CPU_SETSIZE; ++c)
      if (CPU_ISSET(c, &set)) allowed.insert(c);
  if (allowed.empty()) {
    long nc = sysconf(_SC_NPROCESSORS_ONLN);
    for (int c = 0; c < std::max<long>(1, nc); ++c) allowed.insert(c);
  }
  // Primary hardware thread of every physical core (lowest id in sibling list).
  auto isPrimary = [&](int cpu) {
    std::string s;
    if (!readFile("/sys/devices/system/cpu/cpu" + std::to_string(cpu) + "/topology/thread_siblings_list", s)) return true;
    std::vector<int> sib = parseCpuList(s);
    return sib.empty() || *std::min_element(sib.begin(), sib.end()) == cpu;
  };
  std::vector<std::vector<int>> primaryPerNode, smtPerNode;
  std::vector<int> nodeIds;
  std::vector<char> hasMem;
  for (int node = 0; node < 64; ++node) {
    std::string cl;
    if (!readFile("/sys/devices/system/node/node" + std::to_string(node) + "/cpulist", cl)) {
      if (node == 0) continue;
      break;
    }
    std::vector<int> cpus = parseCpuList(cl);
    std::string mi;
    bool mem = true;
    if (readFile("/sys/devices/system/node/node" + std::to_string(node) + "/meminfo", mi)) {
      size_t p = mi.find("MemTotal:");
      if (p != std::string::npos) mem = std::atol(mi.c_str() + p + 9) > 0;
    }
    std::vector<int> prim, smt;
    for (int c : cpus)
      if (allowed.count(c)) (isPrimary(c) ? prim : smt).push_back(c);
    nodeIds.push_back(node);
    hasMem.push_back(mem ? 1 : 0);
    primaryPerNode.push_back(prim);
    smtPerNode.push_back(smt);
    if (mem) info.memNodes.push_back(node);
  }
  if (nodeIds.empty()) {  // no /sys NUMA info: single node, plain CPU order
    info.nodes = 1;
    info.cpuOrder.assign(allowed.begin(), allowed.end());
    return info;
  }
  info.discovered = true;
  info.nodes = static_cast<int>(nodeIds.size());
  // Order: nodes with memory first (round-robin), then memory-less nodes; primaries before SMT.
  auto roundRobin = [&](const std::vector<std::vector<int>>& per, bool wantMem) {
    std::vector<size_t> idx;
    for (size_t k = 0; k < nodeIds.size(); ++k)
      if ((hasMem[k] != 0) == wantMem) idx.push_back(k);
    std::vector<size_t> cursor(per.size(), 0);
    bool any = true;
    while (any) {
      any = false;
      for (size_t k : idx)
        if (cursor[k] < per[k].size()) { info.cpuOrder.push_back(per[k][cursor[k]++]); any = true; }
    }
  };
  roundRobin(primaryPerNode, true);
  roundRobin(primaryPerNode, false);
  roundRobin(smtPerNode, true);
  roundRobin(smtPerNode, false);
  if (info.cpuOrder.empty()) info.cpuOrder.assign(allowed.begin(), allowed.end());
  return info;
}

}  // namespace

const NumaInfo& numaInfo() {
  static const NumaInfo info = discover();
  return info;
}

void pinCurrentThread(int threadIndex) {
  const NumaInfo& ni = numaInfo();
  if (ni.cpuOrder.empty()) return;
  const int cpu = ni.cpuOrder[static_cast<size_t>(threadIndex) % ni.cpuOrder.size()];
  cpu_set_t set;
  CPU_ZERO(&set);
  CPU_SET(cpu, &set);
  pthread_setaffinity_np(pthread_self(), sizeof(set), &set);  // best effort
}

void* numaAllocInterleaved(size_t bytes) {
  void* p = mmap(nullptr, bytes, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
  if (p == MAP_FAILED) return nullptr;
#ifdef MADV_HUGEPAGE
  madvise(p, bytes, MADV_HUGEPAGE);  // fewer page faults / TLB misses for the random-access table
#endif
#ifdef SYS_mbind
  const NumaInfo& ni = numaInfo();
  if (ni.memNodes.size() > 1) {
    unsigned long mask[16];
    std::memset(mask, 0, sizeof(mask));
    int maxNode = 0;
    for (int nd : ni.memNodes) {
      mask[nd / 64] |= 1UL << (nd % 64);
      maxNode = std::max(maxNode, nd);
    }
    const int MPOL_INTERLEAVE_ = 3;
    syscall(SYS_mbind, p, bytes, MPOL_INTERLEAVE_, mask, static_cast<unsigned long>(maxNode + 2), 0u);
  }
#endif
  return p;
}

void numaFree(void* p, size_t bytes) {
  if (p) munmap(p, bytes);
}

size_t availableMemoryBytes() {
  std::string s;
  if (readFile("/proc/meminfo", s)) {
    size_t p = s.find("MemAvailable:");
    if (p != std::string::npos) return static_cast<size_t>(std::atoll(s.c_str() + p + 13)) * 1024ULL;
  }
  long pages = sysconf(_SC_PHYS_PAGES), psz = sysconf(_SC_PAGE_SIZE);
  return pages > 0 && psz > 0 ? static_cast<size_t>(pages) * psz / 2 : (1ULL << 30);
}

}  // namespace sop
