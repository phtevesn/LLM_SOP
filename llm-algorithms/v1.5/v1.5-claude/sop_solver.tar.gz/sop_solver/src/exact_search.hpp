// exact_search.hpp -- parallel branch and bound with DP dominance (exact solver).
#pragma once
#include <atomic>
#include "ap_bound.hpp"
#include "common.hpp"
#include "incumbent.hpp"
#include "model.hpp"

namespace sop {

struct ExactOptions {
  int threads = 1;
  int cpuOffset = 0;              // first CPU-order slot used for pinning exact threads
  double deadline = 1e18;         // absolute global-clock seconds; search aborts after it
  size_t ttBytes = 256ull << 20;  // transposition table size
  u64 seed = 12345;
};

struct ExactResult {
  bool completed = false;   // whole search space exhausted => incumbent is optimal
  u64 nodes = 0;            // search-tree nodes expanded, summed over all threads
};

// Depth-first branch and bound over Hamiltonian paths from s to e.
// Lower bound: root AP dual potentials (reduced costs) + incremental
// "cheapest allowed in-arc" bound. Dominance: shared transposition table over
// (visited set, last node). Work is split dynamically between threads.
ExactResult runExactSearch(const Model& m, const ApResult& ap, Incumbent& inc,
                           const ExactOptions& opt, std::atomic<bool>& stop);

}  // namespace sop
