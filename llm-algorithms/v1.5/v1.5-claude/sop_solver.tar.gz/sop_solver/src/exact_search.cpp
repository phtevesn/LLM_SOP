// =============================================================================
// exact_search.cpp -- exact solver: parallel depth-first branch and bound with
// dynamic-programming dominance and assignment-based reduced-cost bounding.
//
// Techniques implemented here (see ALGORITHMS.md, Table 2a/2c/2d/2e/2f):
//   * DFS branch and bound over path prefixes; branching = next node among the
//     precedence-available nodes (counter of unvisited cover-predecessors),
//     ordered by reduced arc cost
//   * Reduced-cost arc elimination: arcs with reduced cost > UB-1-LB0 are
//     removed before the search (AP dual potentials, Hungarian)
//   * Incremental lower bound: sum over unvisited nodes of the cheapest allowed
//     in-arc reduced cost, maintained with per-node pointers into in-arc lists
//     sorted by reduced cost, with an undo log
//   * Incremental assignment bound: the root AP matching and potentials are kept per
//     depth; one move removes a row and a column and is repaired by ONE shortest
//     augmenting path (Dijkstra on reduced costs, capped by the remaining budget)
//   * Held-Karp style dominance through a shared lock-free transposition table
//     keyed by (visited set, last node) using 2x64-bit Zobrist hashes
//   * Parallelism: shared work queue of path-prefix tasks; a busy thread donates
//     the unexplored siblings of its shallowest open frame whenever a thread
//     is idle (dynamic work splitting); shared atomic incumbent; threads pinned
//     in NUMA-aware order, per-thread state first-touched locally
//   * Termination: search is exhausted when the queue is empty and every
//     worker is idle -> incumbent is proven optimal (all pruning is strict:
//     only completions with cost >= incumbent are discarded)
// Cost is tracked in REDUCED space: path cost = LB0 + sum of reduced arc costs,
// because every s->e path uses the same set of dual rows/columns.
// =============================================================================
#include "exact_search.hpp"

#include <algorithm>
#include <condition_variable>
#include <deque>
#include <mutex>
#include <thread>

#include "numa_topology.hpp"
#include "transposition_table.hpp"

namespace sop {

namespace {

struct Task {
  std::vector<int> prefix;  // nodes after s, in visiting order
};

class SharedSearch {
 public:
  SharedSearch(const Model& m, const ApResult& ap, Incumbent& inc, const ExactOptions& opt,
               std::atomic<bool>& stop)
      : m(m), ap(ap), inc(inc), opt(opt), stop(stop), tt(opt.ttBytes) {
    n = m.n; s = m.s; e = m.e;
    lb0 = ap.valid && !ap.infeasible ? ap.lb : 0;
    buildArcLists();
    Rng rng(opt.seed);
    z1.resize(n); z2.resize(n); w1.resize(n); w2.resize(n);
    for (int i = 0; i < n; ++i) { z1[i] = rng.next(); z2[i] = rng.next(); w1[i] = rng.next(); w2[i] = rng.next(); }
  }

  ExactResult run();

  // ---- immutable problem data (shared, read-only during search) ----
  const Model& m;
  const ApResult& ap;
  Incumbent& inc;
  const ExactOptions& opt;
  std::atomic<bool>& stop;
  TranspositionTable tt;
  int n = 0, s = 0, e = 0;
  i64 lb0 = 0;
  std::vector<int> outHead, outTo, inHead, inFrom;
  std::vector<i64> outR, inR;
  std::vector<u64> z1, z2, w1, w2;
  bool trivialDone = false;  // a node has no admissible in/out arc: nothing better exists

  std::atomic<i64> budget{NO_SOLUTION};  // current iterative-deepening limit on reduced path cost
  u64 salt = 0;                          // per-iteration hash salt: stale TT entries never match
  i64 ubBudget() const {                 // largest reduced path cost that can still beat the incumbent
    const i64 ub = inc.cost();
    return ub >= NO_SOLUTION ? NO_SOLUTION : ub - 1 - lb0;
  }
  i64 maxRed() const { return std::min(ubBudget(), budget.load(std::memory_order_relaxed)); }

  // ---- work queue ----
  std::mutex qmu;
  std::condition_variable qcv;
  std::deque<Task> queue;
  int idle = 0;
  bool done = false;
  bool incomplete = false;
  std::atomic<int> demand{0};  // idle workers not yet covered by queued tasks

  void updateDemandLocked() {
    int d = idle - static_cast<int>(queue.size());
    demand.store(d > 0 ? d : 0, std::memory_order_relaxed);
  }
  bool acquire(Task& t);
  void donate(std::vector<Task>& tasks);

 private:
  void buildArcLists();
};

// ---- Arc lists in CSR form, sorted by reduced cost, filtered by the gap -----
void SharedSearch::buildArcLists() {
  const i64 mr = maxRed();
  std::vector<std::vector<std::pair<i64, int>>> outs(n), ins(n);
  for (int i = 0; i < n; ++i) {
    if (i == e) continue;
    for (int j = 0; j < n; ++j) {
      if (j == s) continue;
      const i64 c = m.c(i, j);
      if (c >= INF_COST) continue;
      i64 r = c - (ap.valid && !ap.infeasible ? ap.a[i] + ap.b[j] : 0);
      if (r < 0) r = 0;  // numerical safety (cannot happen with exact integer duals)
      if (r > mr) continue;  // Reduced-cost fixing: this arc cannot be in an improving path
      outs[i].emplace_back(r, j);
      ins[j].emplace_back(r, i);
    }
  }
  outHead.assign(n + 1, 0);
  inHead.assign(n + 1, 0);
  for (int i = 0; i < n; ++i) {
    std::sort(outs[i].begin(), outs[i].end());
    std::sort(ins[i].begin(), ins[i].end());
    outHead[i + 1] = outHead[i] + static_cast<int>(outs[i].size());
    inHead[i + 1] = inHead[i] + static_cast<int>(ins[i].size());
    if (i != e && outs[i].empty()) trivialDone = true;
    if (i != s && ins[i].empty()) trivialDone = true;
  }
  outTo.resize(outHead[n]); outR.resize(outHead[n]);
  inFrom.resize(inHead[n]); inR.resize(inHead[n]);
  for (int i = 0; i < n; ++i) {
    int a = outHead[i];
    for (auto& pr : outs[i]) { outR[a] = pr.first; outTo[a++] = pr.second; }
    int b = inHead[i];
    for (auto& pr : ins[i]) { inR[b] = pr.first; inFrom[b++] = pr.second; }
  }
}

bool SharedSearch::acquire(Task& t) {
  std::unique_lock<std::mutex> lk(qmu);
  ++idle;
  updateDemandLocked();
  for (;;) {
    if (stop.load(std::memory_order_relaxed)) {  // time limit: leave; unfinished work => incomplete
      if (!queue.empty()) incomplete = true;
      else if (idle == opt.threads) done = true;  // everything had actually finished
      qcv.notify_all();
      return false;
    }
    if (!queue.empty()) {
      t = std::move(queue.front());
      queue.pop_front();
      --idle;
      updateDemandLocked();
      return true;
    }
    if (idle == opt.threads) { done = true; qcv.notify_all(); return false; }  // all idle, queue empty
    if (done) return false;
    qcv.wait_for(lk, std::chrono::milliseconds(20));
  }
}

void SharedSearch::donate(std::vector<Task>& tasks) {
  {
    std::lock_guard<std::mutex> lk(qmu);
    for (auto& t : tasks) queue.push_back(std::move(t));
    updateDemandLocked();
  }
  qcv.notify_all();
}

// =============================================================================
// Worker: owns all per-thread DFS state.
// =============================================================================
class Worker {
 public:
  Worker(SharedSearch& S, int id) : S(S), id(id) {}
  void run();
  u64 nodes = 0;

 private:
  struct Frame {
    int node;
    int idx;        // next out-arc (absolute index) to try
    int undoMark;
    i64 gred;       // reduced cost of the prefix
    i64 hsumPrev;   // incremental bound before entering this node
  };
  struct Undo { int w; int idx; i64 mi; };

  SharedSearch& S;
  int id;
  int n = 0;
  std::vector<char> visited;
  std::vector<int> cnt, ptr, pathPos, path;
  std::vector<i64> mi;
  std::vector<Frame> frames;
  std::vector<Undo> undo;
  // Incremental assignment (AP) state, one snapshot per depth (reduced-cost space)
  std::vector<i64> apA, apB, apDual;   // row/col potentials, dual objective
  std::vector<int> apRM, apCM;         // row->col and col->row mates (-1 = none)
  std::vector<i64> dist;               // Dijkstra labels (per column)
  std::vector<int> prevRow, stampCol;
  int stamp = 0;
  std::vector<std::pair<int, int>> fin; // finalized (column, its old mate row)
  bool apStep(int v, int u, i64 gredChild, i64 mr);
  int depth = 0;
  i64 hsum = 0;
  u64 H1 = 0, H2 = 0;
  u64 tick = 0, donTick = 0;

  void initRoot();
  bool push(int u, i64 r);                  // apply move, update incremental bound
  void pop();                               // undo last move
  bool enter(int u, i64 r, bool checkTT);   // push + bound + leaf + dominance test
  bool findArc(int v, int u, i64& r) const;
  void runTask(const Task& t);
  void tryDonate(int baseDepth);
  bool timeUp();
};

void Worker::initRoot() {
  n = S.n;
  visited.assign(n, 0);
  cnt.assign(n, 0);
  ptr.assign(n, 0);
  pathPos.assign(n, 0);
  path.assign(n + 1, 0);
  mi.assign(n, 0);
  frames.assign(n + 2, Frame());
  undo.clear();
  undo.reserve(4096);
  for (int v = 0; v < n; ++v) cnt[v] = static_cast<int>(S.m.preds[v].size());
  visited[S.s] = 1;
  path[0] = S.s;
  pathPos[S.s] = 0;
  depth = 0;
  H1 = S.z1[S.s] ^ S.salt;
  H2 = S.z2[S.s] ^ ~S.salt;
  for (int x : S.m.succs[S.s]) --cnt[x];
  hsum = 0;
  for (int u = 0; u < n; ++u) {
    if (u == S.s) continue;
    ptr[u] = S.inHead[u];  // all in-arcs allowed at the root (s is the current node)
    mi[u] = S.inR[ptr[u]];
    hsum += mi[u];
  }
  frames[0] = Frame{S.s, S.outHead[S.s], 0, 0, hsum};
  // AP snapshot at depth 0 = root optimum: potentials 0 in reduced space, dual 0
  const size_t sz = static_cast<size_t>(n + 2) * n;
  apA.assign(sz, 0); apB.assign(sz, 0); apRM.assign(sz, -1); apCM.assign(sz, -1);
  apDual.assign(n + 2, 0);
  for (int i = 0; i < n; ++i) { apRM[i] = S.ap.rowMate[i]; apCM[i] = S.ap.colMate[i]; }
  dist.assign(n, 0); prevRow.assign(n, -1); stampCol.assign(n, 0);
  fin.reserve(n);
}

// Child of the current node via arc (v,u): drop row v and column u from the
// parent's optimal assignment and repair it with one shortest augmenting path.
// Returns false if no perfect assignment exists or the repaired bound exceeds
// the budget (child pruned). Bound semantics: dual objective = sum of reduced
// costs of the matched arcs = lower bound on the reduced cost of the completion.
bool Worker::apStep(int v, int u, i64 gredChild, i64 mr) {
  const int d = depth;                       // child depth (already incremented)
  const size_t po = static_cast<size_t>(d - 1) * n, co = static_cast<size_t>(d) * n;
  const i64 base = apDual[d - 1] - apA[po + v] - apB[po + u];
  const i64 cap = mr - gredChild - base;     // largest affordable augmentation cost
  if (cap < 0) return false;
  std::copy(apA.begin() + po, apA.begin() + po + n, apA.begin() + co);
  std::copy(apB.begin() + po, apB.begin() + po + n, apB.begin() + co);
  std::copy(apRM.begin() + po, apRM.begin() + po + n, apRM.begin() + co);
  std::copy(apCM.begin() + po, apCM.begin() + po + n, apCM.begin() + co);
  i64* a = &apA[co]; i64* b = &apB[co]; int* rm = &apRM[co]; int* cm = &apCM[co];
  const int w = rm[v], x = cm[u];
  rm[v] = -1; cm[u] = -1;
  if (w == u) { apDual[d] = base; return true; }  // matched arc (v,u) removed, still optimal
  // free row x, free column w
  rm[x] = -1; cm[w] = -1;
  ++stamp;
  fin.clear();
  struct HE { i64 d; int j; bool operator>(const HE& o) const { return d > o.d; } };
  static thread_local std::vector<HE> heapBuf;  // binary min-heap storage reused across calls
  heapBuf.clear();
  auto relaxRow = [&](int i, i64 di) {
    for (int arc = S.outHead[i]; arc < S.outHead[i + 1]; ++arc) {
      const int j = S.outTo[arc];
      if (visited[j]) continue;                 // column already consumed (includes u)
      const i64 rp = S.outR[arc] - a[i] - b[j];
      const i64 nd = di + rp;
      if (nd > cap) continue;
      if (stampCol[j] != stamp) { stampCol[j] = stamp; dist[j] = nd; prevRow[j] = i; heapBuf.push_back({nd, j}); std::push_heap(heapBuf.begin(), heapBuf.end(), std::greater<HE>()); }
      else if (nd < dist[j]) { dist[j] = nd; prevRow[j] = i; heapBuf.push_back({nd, j}); std::push_heap(heapBuf.begin(), heapBuf.end(), std::greater<HE>()); }
    }
  };
  relaxRow(x, 0);
  i64 D = -1;
  static thread_local std::vector<int> finMark;
  if (static_cast<int>(finMark.size()) < n) finMark.assign(n, 0);
  static thread_local int finStamp = 0;
  ++finStamp;
  while (!heapBuf.empty()) {
    std::pop_heap(heapBuf.begin(), heapBuf.end(), std::greater<HE>());
    const HE h = heapBuf.back();
    heapBuf.pop_back();
    if (finMark[h.j] == finStamp || h.d != dist[h.j]) continue;  // stale entry
    finMark[h.j] = finStamp;
    if (h.j == w) { D = h.d; break; }
    const int i2 = cm[h.j];                      // row currently matched to this column
    fin.emplace_back(h.j, i2);
    relaxRow(i2, h.d);
  }
  if (D < 0) return false;                       // no augmenting path within budget
  // dual update on finalized columns/rows, then augment along prevRow chain
  a[x] += D;
  for (auto& f : fin) {
    const i64 delta = D - dist[f.first];
    b[f.first] -= delta;
    a[f.second] += delta;
  }
  int j = w;
  for (;;) {
    const int i = prevRow[j];
    const int nextj = rm[i];                     // previous column of row i (-1 for x)
    rm[i] = j; cm[j] = i;
    if (i == x) break;
    j = nextj;
  }
  apDual[d] = base + D;
  return true;
}


// Move from path[depth] to u. Maintains: visited, cover-predecessor counters,
// Zobrist hashes, and the "cheapest allowed in-arc" bound. The old current node
// v stops being an allowed predecessor, so only nodes whose pointer sits on v
// need to advance (each such change is logged for undo).
bool Worker::push(int u, i64 r) {
  const int v = path[depth];
  Frame& nf = frames[depth + 1];
  nf.node = u;
  nf.gred = frames[depth].gred + r;
  nf.undoMark = static_cast<int>(undo.size());
  nf.hsumPrev = hsum;
  nf.idx = S.outHead[u];
  ++depth;
  path[depth] = u;
  pathPos[u] = depth;
  visited[u] = 1;
  H1 ^= S.z1[u];
  H2 ^= S.z2[u];
  for (int x : S.m.succs[u]) --cnt[x];
  hsum -= mi[u];
  const i64 mr = S.maxRed();
  for (int a = S.outHead[v]; a < S.outHead[v + 1]; ++a) {
    // a node whose pointer sits on v with r > mr would already have pruned the parent
    if (S.outR[a] > mr) break;
    const int w = S.outTo[a];
    if (visited[w]) continue;
    int idx = ptr[w];
    if (S.inFrom[idx] != v) continue;
    undo.push_back(Undo{w, idx, mi[w]});
    const int end = S.inHead[w + 1];
    ++idx;
    while (idx < end) {
      const int p = S.inFrom[idx];
      if (!visited[p] || p == u) break;
      ++idx;
    }
    if (idx == end) return false;  // w has no admissible predecessor left: dead end
    hsum += S.inR[idx] - mi[w];
    ptr[w] = idx;
    mi[w] = S.inR[idx];
  }
  if (nf.gred + hsum > mr) return false;
  return apStep(v, u, nf.gred, mr);
}

void Worker::pop() {
  const Frame& f = frames[depth];
  const int u = f.node;
  while (static_cast<int>(undo.size()) > f.undoMark) {
    const Undo& r = undo.back();
    ptr[r.w] = r.idx;
    mi[r.w] = r.mi;
    undo.pop_back();
  }
  hsum = f.hsumPrev;
  for (int x : S.m.succs[u]) ++cnt[x];
  H1 ^= S.z1[u];
  H2 ^= S.z2[u];
  visited[u] = 0;
  --depth;
}

bool Worker::enter(int u, i64 r, bool checkTT) {
  if (!push(u, r)) { pop(); return false; }  // lower-bound pruning
  if (depth == n - 1) {                       // complete path s ... e
    ++nodes;
    const i64 total = S.lb0 + frames[depth].gred;
    if (total < S.inc.cost()) S.inc.offer(total, std::vector<int>(path.begin(), path.begin() + n), "B&B");
    pop();
    return false;
  }
  if (checkTT && S.tt.probeAndStore(H1 ^ S.w1[u], H2 ^ S.w2[u], frames[depth].gred, depth)) {
    pop();  // dominated by an earlier arrival at the same (set,last) state
    return false;
  }
  ++nodes;
  return true;
}

bool Worker::findArc(int v, int u, i64& r) const {
  for (int a = S.outHead[v]; a < S.outHead[v + 1]; ++a)
    if (S.outTo[a] == u) { r = S.outR[a]; return true; }
  return false;
}

bool Worker::timeUp() {
  if (S.stop.load(std::memory_order_relaxed)) return true;
  if (globalClock().seconds() >= S.opt.deadline) {
    S.stop.store(true, std::memory_order_relaxed);
    return true;
  }
  return false;
}

// Dynamic work splitting: give the unexplored siblings of the shallowest open
// frame to idle workers (as path-prefix tasks).
void Worker::tryDonate(int baseDepth) {
  const i64 mr = S.maxRed();
  for (int f = baseDepth; f <= depth; ++f) {
    Frame& F = frames[f];
    const int aend = S.outHead[F.node + 1];
    std::vector<Task> tasks;
    for (int a = F.idx; a < aend; ++a) {
      if (F.gred + S.outR[a] > mr) break;
      const int u = S.outTo[a];
      if (visited[u] && pathPos[u] <= f) continue;  // already on the prefix at that time
      bool ready = true;
      for (int p : S.m.preds[u])
        if (!visited[p] || pathPos[p] > f) { ready = false; break; }
      if (!ready) continue;
      Task t;
      t.prefix.assign(path.begin() + 1, path.begin() + f + 1);
      t.prefix.push_back(u);
      tasks.push_back(std::move(t));
    }
    if (!tasks.empty()) {
      F.idx = aend;  // siblings now belong to the queue
      S.donate(tasks);
      return;
    }
  }
}

void Worker::runTask(const Task& t) {
  const size_t L = t.prefix.size();
  bool ok = true;
  for (size_t k = 0; k < L && ok; ++k) {
    const int u = t.prefix[k];
    const int v = path[depth];
    i64 r = 0;
    if (visited[u] || cnt[u] != 0 || !findArc(v, u, r)) { ok = false; break; }
    if (!enter(u, r, k + 1 == L)) { ok = false; break; }
    if (k + 1 < L) frames[depth].idx = S.outHead[u + 1];  // replayed prefix frame: closed
  }
  if (ok) {
    if (L == 0) ++nodes;  // root
    const int baseDepth = depth;
    bool interrupted = false;
    for (;;) {
      Frame& F = frames[depth];
      const int aend = S.outHead[F.node + 1];
      const i64 mr = S.maxRed();
      bool found = false;
      while (F.idx < aend) {
        const int a = F.idx++;
        const i64 r = S.outR[a];
        if (F.gred + r > mr) { F.idx = aend; break; }  // arcs are sorted by reduced cost
        const int u = S.outTo[a];
        if (visited[u] || cnt[u] != 0) continue;
        if (enter(u, r, true)) { found = true; break; }
      }
      if (found) {
        if ((++tick & 127) == 0 && timeUp()) { interrupted = true; break; }
        if (S.demand.load(std::memory_order_relaxed) > 0 && (++donTick & 15) == 0) tryDonate(baseDepth);
        continue;
      }
      if (depth == baseDepth) break;
      pop();
    }
    if (interrupted) {
      std::lock_guard<std::mutex> lk(S.qmu);
      S.incomplete = true;
    }
  }
  while (depth > 0) pop();  // unwind to the root state
}

void Worker::run() {
  pinCurrentThread(S.opt.cpuOffset + id);  // NUMA-aware placement before first touch
  initRoot();
  Task t;
  while (S.acquire(t)) runTask(t);
}

ExactResult SharedSearch::run() {
  ExactResult res;
  if (!tt.ok()) logf("warning: transposition table allocation failed; dominance disabled");
  if (trivialDone) {  // some node has no admissible arc within the gap: incumbent is optimal
    res.completed = true;
    return res;
  }
  // Iterative deepening on the reduced-cost budget B ("gap budget"): path cost =
  // LB0 + reduced cost, so iteration B searches exhaustively for paths with cost
  // <= LB0 + B. A failed iteration raises the proven lower bound to LB0+B+1; the
  // first success gives an incumbent; the iteration whose budget reaches
  // UB-1-LB0 is the optimality proof. Geometric growth bounds the overhead.
  const i64 CAP = static_cast<i64>(1) << 50;
  logf("exact search: %zu arcs kept after reduced-cost elimination (root LB %lld)", outR.size(),
       static_cast<long long>(lb0));
  i64 B = 0;
  u64 saltState = opt.seed * 0x9E3779B97F4A7C15ULL + 12345;
  for (int iter = 0;; ++iter) {
    const bool finalIter = B >= ubBudget() || B >= CAP;
    budget.store(finalIter ? NO_SOLUTION : B, std::memory_order_relaxed);
    salt = splitmix64(saltState);
    {
      std::lock_guard<std::mutex> lk(qmu);
      queue.clear();
      queue.push_back(Task());  // root task
      idle = 0; done = false; incomplete = false;
      updateDemandLocked();
    }
    std::vector<Worker> workers;
    workers.reserve(opt.threads);
    for (int i = 0; i < opt.threads; ++i) workers.emplace_back(*this, i);
    std::vector<std::thread> th;
    for (int i = 1; i < opt.threads; ++i) th.emplace_back([&workers, i]() { workers[i].run(); });
    workers[0].run();
    for (auto& t : th) t.join();
    u64 it = 0;
    for (auto& w : workers) it += w.nodes;
    res.nodes += it;
    if (!(done && !incomplete)) { res.completed = false; return res; }  // time limit
    if (finalIter || B >= ubBudget()) { res.completed = true; return res; }
    logf("exact: no path with cost <= %lld exists (budget iteration %d, %llu nodes); lower bound raised",
         static_cast<long long>(lb0 + B), iter, static_cast<unsigned long long>(it));
    B = std::max<i64>(B + 1, B + B / 2);
  }
}

}  // namespace

ExactResult runExactSearch(const Model& m, const ApResult& ap, Incumbent& inc, const ExactOptions& opt,
                           std::atomic<bool>& stop) {
  SharedSearch S(m, ap, inc, opt, stop);
  return S.run();
}

}  // namespace sop
