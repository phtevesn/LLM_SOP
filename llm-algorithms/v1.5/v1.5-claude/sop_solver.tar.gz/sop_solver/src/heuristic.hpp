// heuristic.hpp -- upper-bounding heuristics (randomized greedy + ILS with
// precedence-aware segment insertion local search).
#pragma once
#include <atomic>
#include <vector>
#include "common.hpp"
#include "ap_bound.hpp"
#include "incumbent.hpp"
#include "model.hpp"

namespace sop {

// Read-only candidate lists shared by all heuristic threads.
struct HeuristicData {
  int K = 0;                                  // candidate list length
  std::vector<std::vector<int>> candIn;       // K cheapest feasible predecessors of each node
  std::vector<std::vector<int>> candOut;      // K cheapest feasible successors of each node
  // When built from AP duals, candidates are ranked by REDUCED cost (an
  // "alpha-nearness"-like measure: arcs of near-optimal paths have tiny reduced
  // cost) and the greedy construction follows reduced costs as well.
  bool reduced = false;
  std::vector<i64> redA, redB;                // AP row/column duals per node
  std::vector<int> apSucc;                    // AP optimum: successor chosen by each node (-1 for end)
};
// ap == nullptr -> candidates ranked by raw arc cost.
HeuristicData buildHeuristicData(const Model& m, int K, const ApResult* ap = nullptr);

// One iterated-local-search worker. Several run in parallel with different
// seeds; they cooperate only through the shared Incumbent.
class IlsWorker {
 public:
  // `src` points at the candidate data currently in use; it may be replaced by a
  // better (reduced-cost) one while the worker runs, which triggers a restart.
  IlsWorker(const Model& m, const std::atomic<const HeuristicData*>& src, Incumbent& inc, u64 seed);
  // Runs until `stop` is set, or until the clock passes `deadline` AND the global
  // incumbent has not improved for `stallWindow` seconds, or `hardDeadline` passes.
  void run(const std::atomic<bool>& stop, double deadline, double hardDeadline, double stallWindow);
  u64 iterations() const { return iters_; }

 private:
  bool construct();                  // randomized nearest-neighbour construction
  bool constructAp(bool randomized); // AP cycle patching + precedence repair (needs reduced data)
  bool freshStart();                 // best available construction for a (re)start
  i64 arcKey(int i, int j) const;    // reduced cost if available, else raw cost
  i64 pathCost() const;
  void localSearch();                // queue-driven segment insertion descent
  bool tryMove(int i, int j);        // best improving relocation of segment p[i..j]
  bool feasibleMove(int i, int j, int k) const;
  void applyMove(int i, int j, int k, i64 delta);
  void pushNode(int v);
  void kick(int strength);           // random feasible segment relocations
  void rebuildPos();

  const Model& m_;
  const std::atomic<const HeuristicData*>& src_;
  const HeuristicData* hd_;
  Incumbent& inc_;
  Rng rng_;
  int n_;
  int maxSeg_;
  std::vector<int> p_, pos_;
  i64 cost_ = 0;
  std::vector<int> stack_;
  std::vector<char> inStack_;
  u64 iters_ = 0;
};

}  // namespace sop
