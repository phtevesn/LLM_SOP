// =============================================================================
// ap_bound.cpp -- root lower bound via the assignment-problem relaxation.
//
// Algorithm: Hungarian method with shortest augmenting paths and dual
// potentials (Kuhn 1955; Munkres 1957; Jonker & Volgenant 1987; the compact
// O(n^3) formulation popularised by e-maxx). The AP relaxation of a path
// problem drops the subtour-elimination constraints; it is the classic bound
// for ATSP/SOP branch and bound (Carpaneto & Toth 1980; Escudero 1988).
// The optimal dual potentials are kept: they turn every arc cost into a
// non-negative reduced cost, which the exact search uses both for arc
// elimination (reduced-cost fixing) and for incremental bounding.
// =============================================================================
#include "ap_bound.hpp"

#include <algorithm>

namespace sop {

ApResult solveAssignmentBound(const Model& m, const std::atomic<bool>* stop) {
  ApResult res;
  const int n = m.n;
  res.a.assign(n, 0);
  res.b.assign(n, 0);
  res.rowMate.assign(n, -1);
  res.colMate.assign(n, -1);
  if (n < 2) { res.valid = true; return res; }

  // Rows = every node except the end; columns = every node except the start.
  std::vector<int> rowNode, colNode;
  for (int v = 0; v < n; ++v) {
    if (v != m.e) rowNode.push_back(v);
    if (v != m.s) colNode.push_back(v);
  }
  const int sz = static_cast<int>(rowNode.size());  // == n-1
  std::vector<i64> A(static_cast<size_t>(sz) * sz);
  for (int r = 0; r < sz; ++r)
    for (int c = 0; c < sz; ++c) A[static_cast<size_t>(r) * sz + c] = m.c(rowNode[r], colNode[c]);

  // ---- Hungarian algorithm with potentials (1-based arrays as in e-maxx) ---
  const i64 BIG = INT64_MAX / 4;
  std::vector<i64> u(sz + 1, 0), v(sz + 1, 0), minv(sz + 1);
  std::vector<int> p(sz + 1, 0), way(sz + 1, 0);
  std::vector<char> used(sz + 1);
  for (int i = 1; i <= sz; ++i) {
    if (stop && stop->load(std::memory_order_relaxed)) return res;  // aborted
    p[0] = i;
    int j0 = 0;
    std::fill(minv.begin(), minv.end(), BIG);
    std::fill(used.begin(), used.end(), 0);
    do {
      used[j0] = 1;
      const int i0 = p[j0];
      i64 delta = BIG;
      int j1 = 0;
      const i64* row = &A[static_cast<size_t>(i0 - 1) * sz];
      const i64 ui0 = u[i0];
      for (int j = 1; j <= sz; ++j) {
        if (used[j]) continue;
        const i64 cur = row[j - 1] - ui0 - v[j];
        if (cur < minv[j]) { minv[j] = cur; way[j] = j0; }
        if (minv[j] < delta) { delta = minv[j]; j1 = j; }
      }
      for (int j = 0; j <= sz; ++j) {
        if (used[j]) { u[p[j]] += delta; v[j] -= delta; }
        else minv[j] -= delta;
      }
      j0 = j1;
    } while (p[j0] != 0);
    do {
      const int j1 = way[j0];
      p[j0] = p[j1];
      j0 = j1;
    } while (j0 != 0);
  }

  // ---- Extract bound and duals --------------------------------------------
  i64 total = 0;
  for (int j = 1; j <= sz; ++j) total += A[static_cast<size_t>(p[j] - 1) * sz + (j - 1)];
  res.valid = true;
  if (total >= INF_COST) { res.infeasible = true; return res; }
  res.lb = total;
  for (int r = 1; r <= sz; ++r) res.a[rowNode[r - 1]] = u[r];
  for (int c = 1; c <= sz; ++c) res.b[colNode[c - 1]] = v[c];
  for (int c = 1; c <= sz; ++c) {
    res.rowMate[rowNode[p[c] - 1]] = colNode[c - 1];
    res.colMate[colNode[c - 1]] = rowNode[p[c] - 1];
  }
  return res;
}

}  // namespace sop
