// transposition_table.cpp -- lock-free, lossy, NUMA-interleaved dominance table.
// Purpose: DP-style duplicate/dominance detection of (visited set, last node)
// states shared by all branch-and-bound threads (see header for layout).
#include "transposition_table.hpp"

#include "numa_topology.hpp"

namespace sop {

TranspositionTable::TranspositionTable(size_t bytes) {
  size_t slots = 1024;
  while (slots * 2 * sizeof(Slot) <= bytes) slots *= 2;  // largest power of two <= bytes
  size_t buckets = slots / 2;
  while (buckets >= 1024) {
    bytes_ = buckets * 2 * sizeof(Slot);
    void* p = numaAllocInterleaved(bytes_);
    if (p) {
      slots_ = static_cast<Slot*>(p);
      bucketMask_ = buckets - 1;
      return;
    }
    buckets /= 2;  // allocation refused: retry with half the size
  }
  bytes_ = 0;
}

TranspositionTable::~TranspositionTable() {
  if (slots_) numaFree(slots_, bytes_);
}

bool TranspositionTable::probeAndStore(u64 k1, u64 k2, i64 g, int depth) {
  if (!slots_ || g < 0 || g >= (static_cast<i64>(1) << 46)) return false;  // cannot encode: no pruning
  if (k1 == 0) k1 = 1;
  Slot* b = &slots_[(k1 & bucketMask_) * 2];
  const u64 data = (static_cast<u64>(g) << 16) | static_cast<u64>(depth & 0xFFFF);
  int victim = -1;
  int depth0 = -1;
  for (int s = 0; s < 2; ++s) {
    const u64 w0 = b[s].w[0].load(std::memory_order_relaxed);
    const u64 w1 = b[s].w[1].load(std::memory_order_relaxed);
    const u64 w2 = b[s].w[2].load(std::memory_order_relaxed);
    const u64 w3 = b[s].w[3].load(std::memory_order_relaxed);
    if (w3 != (w0 ^ w1 ^ w2) || w0 == 0) {  // empty or torn slot
      if (victim < 0) victim = s;
      continue;
    }
    if (w0 == k1 && w1 == k2) {
      if (static_cast<i64>(w2 >> 16) <= g) return true;  // dominated
      b[s].w[2].store(data, std::memory_order_relaxed);   // better arrival: update in place
      b[s].w[3].store(k1 ^ k2 ^ data, std::memory_order_relaxed);
      return false;
    }
    if (s == 0) depth0 = static_cast<int>(w2 & 0xFFFF);
  }
  if (victim < 0) victim = (depth <= depth0) ? 0 : 1;  // depth-preferred / always-replace policy
  b[victim].w[0].store(k1, std::memory_order_relaxed);
  b[victim].w[1].store(k2, std::memory_order_relaxed);
  b[victim].w[2].store(data, std::memory_order_relaxed);
  b[victim].w[3].store(k1 ^ k2 ^ data, std::memory_order_relaxed);
  return false;
}

}  // namespace sop
