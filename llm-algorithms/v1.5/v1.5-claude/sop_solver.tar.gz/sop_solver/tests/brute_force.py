#!/usr/bin/env python3
"""Independent exact reference: Held-Karp DP over precedence-closed subsets.
Handles several sources/sinks natively (any source may start, any last node may end).
usage: brute_force.py file.sop  -> prints optimal cost, or -1 if no feasible order exists
"""
import re, sys

def main():
    txt = open(sys.argv[1]).read()
    i = txt.index("EDGE_WEIGHT_SECTION") + len("EDGE_WEIGHT_SECTION")
    toks = [int(t) for t in re.findall(r'-?\d+', txt[i:])]
    n = toks[0]; v = toks[1:1 + n * n]
    T = [v[r * n:(r + 1) * n] for r in range(n)]
    pred = [0] * n
    for a in range(n):
        for b in range(n):
            if a != b and T[a][b] < 0: pred[a] |= 1 << b
    INF = float("inf")
    dp = {}
    for u in range(n):
        if pred[u] == 0: dp[(1 << u, u)] = 0
    for size in range(1, n):
        nxt = {}
        for (mask, last), c in dp.items():
            if bin(mask).count("1") != size: continue
            for u in range(n):
                if mask >> u & 1 or (pred[u] & ~mask): continue
                if T[last][u] < 0: continue
                key = (mask | 1 << u, u); nc = c + T[last][u]
                if nc < nxt.get(key, INF): nxt[key] = nc
        dp = {**{k: x for k, x in dp.items() if bin(k[0]).count("1") != size}, **nxt}
    full = (1 << n) - 1
    best = min([c for (m, l), c in dp.items() if m == full], default=None)
    print(-1 if best is None else best)

main()
