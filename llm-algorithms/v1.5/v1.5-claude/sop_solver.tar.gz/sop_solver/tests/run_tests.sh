#!/usr/bin/env bash
# Randomized correctness test: solver vs independent brute-force DP on small instances.
# usage: bash tests/run_tests.sh [NUM_CASES] [THREADS]
set -u
cd "$(dirname "$0")/.."
NUM=${1:-60}; THREADS=${2:-1}
TMP=$(mktemp -d); fail=0; pass=0
for seed in $(seq 1 "$NUM"); do
  n=$(( 3 + seed % 9 ))                                  # N in 3..11
  dens=$(python3 -c "print([0.0,0.05,0.15,0.3,0.6][$seed % 5])")
  cmax=$(( seed % 3 == 0 ? 4 : 100 ))                    # tiny costs create many ties
  unique=$(( seed % 2 )); wrap=$(( (seed / 2) % 2 )); eof=$(( (seed / 3) % 2 ))
  python3 tests/gen_random_sop.py "$n" "$seed" "$dens" "$cmax" "$unique" "$wrap" "$eof" > "$TMP/t.sop"
  ref=$(python3 tests/brute_force.py "$TMP/t.sop")
  out=$(./sop_solver "$TMP/t.sop" --threads "$THREADS" --no-header 2>/dev/null)
  cost=$(echo "$out" | awk -F, '{print $5}'); opt=$(echo "$out" | awk -F, '{print $7}')
  if [ "$cost" == "$ref" ] && { [ "$opt" == "yes" ] || [ "$ref" == "-1" ]; }; then pass=$((pass+1));
  else fail=$((fail+1)); echo "FAIL seed=$seed n=$n dens=$dens unique=$unique ref=$ref got=$cost optimal=$opt"; cp "$TMP/t.sop" "/tmp/fail_$seed.sop"; fi
done
echo "random tests: $pass passed, $fail failed (threads=$THREADS)"
# special cases: N=1, N=2, precedence cycle
printf 'NAME: one\nDIMENSION: 1\nEDGE_WEIGHT_TYPE: EXPLICIT\nEDGE_WEIGHT_FORMAT: FULL_MATRIX\nEDGE_WEIGHT_SECTION\n1\n0\nEOF\n' > "$TMP/one.sop"
printf 'NAME: two\nDIMENSION: 2\nEDGE_WEIGHT_TYPE: EXPLICIT\nEDGE_WEIGHT_FORMAT: FULL_MATRIX\nEDGE_WEIGHT_SECTION\n2\n0 7\n-1 0\n' > "$TMP/two.sop"
printf 'NAME: cyc\nDIMENSION: 3\nEDGE_WEIGHT_TYPE: EXPLICIT\nEDGE_WEIGHT_FORMAT: FULL_MATRIX\nEDGE_WEIGHT_SECTION\n3\n0 -1 1\n-1 0 1\n1 1 0\nEOF\n' > "$TMP/cyc.sop"
./sop_solver "$TMP/one.sop" --no-header 2>/dev/null; ./sop_solver "$TMP/two.sop" --no-header 2>/dev/null; ./sop_solver "$TMP/cyc.sop" --no-header 2>/dev/null
rm -rf "$TMP"
[ "$fail" -eq 0 ]
