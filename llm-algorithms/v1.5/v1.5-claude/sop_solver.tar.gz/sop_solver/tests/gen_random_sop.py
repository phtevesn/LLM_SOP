#!/usr/bin/env python3
"""Random SOP instance generator for testing (TSPLIB-style FULL_MATRIX).

usage: gen_random_sop.py N SEED DENSITY COSTMAX UNIQUE(0/1) WRAP(0/1) EOF(0/1) > out.sop
 * precedence pairs are drawn along a hidden random order, so the instance is acyclic
 * UNIQUE=1 forces a single source and a single sink (like the benchmark files);
   UNIQUE=0 leaves several sources/sinks (exercises the dummy start/end logic)
 * WRAP=1 wraps the matrix over several lines; EOF=0 omits the EOF line
 * optional 8th argument CHAINLEN>0 replaces the random pairs by disjoint chains of that
   length (all pairs inside a chain are constrained), giving a transitively closed sparse
   relation like the real R.* benchmark files (DENSITY is then ignored)
"""
import random, sys

def main():
    n, seed, dens, cmax, unique, wrap, eof = (int(sys.argv[1]), int(sys.argv[2]), float(sys.argv[3]),
                                              int(sys.argv[4]), int(sys.argv[5]), int(sys.argv[6]), int(sys.argv[7]))
    chainlen = int(sys.argv[8]) if len(sys.argv) > 8 else 0
    rnd = random.Random(seed)
    order = list(range(n)); rnd.shuffle(order)
    T = [[rnd.randint(0, cmax) for _ in range(n)] for _ in range(n)]
    for i in range(n): T[i][i] = 0
    if chainlen > 0:
        nodes = list(range(n)); rnd.shuffle(nodes)
        for c0 in range(0, n, chainlen):
            rank = {v: r for r, v in enumerate(order)}
            ch = sorted(nodes[c0:c0 + chainlen], key=lambda v: rank[v])  # consistent with hidden order
            for a in range(len(ch)):
                for b in range(a + 1, len(ch)):
                    T[ch[b]][ch[a]] = -1            # ch[b] depends on ch[a]
    else:
      for a in range(n):
        for b in range(a + 1, n):
            if rnd.random() < dens:
                T[order[b]][order[a]] = -1          # order[b] depends on order[a]
    if unique and n > 1:
        for x in order[1:]: T[x][order[0]] = -1     # order[0] first
        for x in order[:-1]: T[order[-1]][x] = -1   # order[-1] last
    print("NAME: rnd%d_%d.sop\nTYPE: SOP\nCOMMENT: generated for tests\nDIMENSION: %d" % (n, seed, n))
    print("EDGE_WEIGHT_TYPE: EXPLICIT\nEDGE_WEIGHT_FORMAT: FULL_MATRIX \nEDGE_WEIGHT_SECTION\n%d" % n)
    flat = [str(v) for row in T for v in row]
    if wrap:
        for k in range(0, len(flat), 17): print(" ".join(flat[k:k + 17]))
    else:
        for r in range(n): print(" ".join(flat[r * n:(r + 1) * n]))
    if eof: print("EOF")

main()
